import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wifi, WifiOff, CloudLightning, RefreshCw, CheckCircle2 } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [showNotification, setShowNotification] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced'>('idle');

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setSyncStatus('syncing');
      setShowNotification(true);
      
      // Simulate database synching from LocalStorage/IndexedDB cache to Firestore
      setTimeout(() => {
        setSyncStatus('synced');
        setTimeout(() => {
          setShowNotification(false);
          setSyncStatus('idle');
        }, 3000);
      }, 2000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus('idle');
      setShowNotification(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <AnimatePresence>
        {showNotification && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className={`p-4 rounded-2xl border shadow-lg flex items-center gap-3 max-w-sm ${
              isOnline 
                ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
                : 'bg-amber-50 border-amber-100 text-amber-800'
            }`}
          >
            {isOnline ? (
              syncStatus === 'syncing' ? (
                <RefreshCw className="h-5 w-5 text-emerald-600 animate-spin" />
              ) : (
                <CheckCircle2 className="h-5 w-5 text-emerald-500 animate-pulse" />
              )
            ) : (
              <WifiOff className="h-5 w-5 text-amber-600 animate-bounce" />
            )}

            <div>
              <span className="text-xs font-bold block">
                {isOnline 
                  ? (syncStatus === 'syncing' ? 'Cloud Syncing Active' : 'Synced with Cloud') 
                  : 'Offline (Subway Mode)'}
              </span>
              <span className="text-[10px] text-gray-500 block leading-tight mt-0.5">
                {isOnline 
                  ? (syncStatus === 'syncing' ? 'Syncing local offline drafts with Firestore...' : 'All local changes successfully synchronized.')
                  : 'No internet connection. Receipts and splits will be cached locally and synced on reconnect.'}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Persistent floating indicator badge */}
      {!showNotification && (
        <div className={`p-2 rounded-xl border shadow-xs flex items-center gap-1.5 bg-white ${
          isOnline ? 'border-gray-100' : 'border-amber-100 text-amber-800 bg-amber-50/50'
        }`}>
          <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-amber-500 animate-ping'}`} />
          <span className="text-[10px] font-mono font-bold text-gray-500">
            {isOnline ? 'ONLINE' : 'SUBWAY MODE'}
          </span>
        </div>
      )}
    </div>
  );
};
