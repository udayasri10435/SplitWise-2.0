import React, { useMemo } from 'react';
import { Group, Expense } from '../types';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, DollarSign, RefreshCw, Zap } from 'lucide-react';

interface DebtSimplifierProps {
  group: Group;
  expenses: Expense[];
  onSettle: (debtor: string, creditor: string, amount: number) => void;
  currencySymbol: string;
}

interface Transaction {
  from: string;
  to: string;
  amount: number;
}

export const DebtSimplifier: React.FC<DebtSimplifierProps> = ({
  group,
  expenses,
  onSettle,
  currencySymbol,
}) => {
  // 1. Calculate net balances for each group member
  const balances: { [email: string]: number } = useMemo(() => {
    const memberBalances: { [email: string]: number } = {};
    group.members.forEach((email) => {
      memberBalances[email] = 0;
    });

    // Only look at non-deleted expenses
    const activeExpenses = expenses.filter((e) => !e.deletedAt);

    activeExpenses.forEach((expense) => {
      const payer = expense.paidBy;
      const totalAmount = expense.totalAmount;

      if (!group.members.includes(payer)) return;

      // Add full amount as credit to the payer
      memberBalances[payer] += totalAmount;

      // Determine split breakdown
      if (expense.items && expense.items.length > 0) {
        // Advanced Itemized Split:
        // Calculate each member's specific item costs
        const itemOwes: { [email: string]: number } = {};
        group.members.forEach((m) => {
          itemOwes[m] = 0;
        });

        let totalAssignedCost = 0;

        expense.items.forEach((item) => {
          const assignees = item.assignedTo && item.assignedTo.length > 0
            ? item.assignedTo
            : group.members; // fallback to all if unassigned

          const share = item.price / assignees.length;
          assignees.forEach((email) => {
            if (group.members.includes(email)) {
              itemOwes[email] += share;
              totalAssignedCost += share;
            }
          });
        });

        // Pro-rate tax and other overhead costs across members based on their item consumption
        const remainingOverhead = totalAmount - totalAssignedCost;
        group.members.forEach((email) => {
          let share = 0;
          if (totalAssignedCost > 0) {
            share = itemOwes[email] + (remainingOverhead * (itemOwes[email] / totalAssignedCost));
          } else {
            // fallback equal split
            share = totalAmount / group.members.length;
          }
          memberBalances[email] -= share;
        });
      } else {
        // Simple Split: split equally among all group members
        const share = totalAmount / group.members.length;
        group.members.forEach((email) => {
          memberBalances[email] -= share;
        });
      }
    });

    // Round values to 2 decimal places to avoid float inaccuracies
    Object.keys(memberBalances).forEach((key) => {
      memberBalances[key] = Math.round(memberBalances[key] * 100) / 100;
    });

    return memberBalances;
  }, [group, expenses]);

  // 2. Greedily simplify debts (Minimum Cash Flow algorithm)
  const transactions = useMemo(() => {
    // Clone balances
    const activeBalances = { ...balances };

    const debtors: { email: string; balance: number }[] = [];
    const creditors: { email: string; balance: number }[] = [];

    Object.entries(activeBalances).forEach(([email, balance]) => {
      if (balance < -0.01) {
        debtors.push({ email, balance: Math.abs(balance) });
      } else if (balance > 0.01) {
        creditors.push({ email, balance });
      }
    });

    // Sort descending to always match largest debtor and largest creditor
    debtors.sort((a, b) => b.balance - a.balance);
    creditors.sort((a, b) => b.balance - a.balance);

    const result: Transaction[] = [];
    let dIdx = 0;
    let cIdx = 0;

    while (dIdx < debtors.length && cIdx < creditors.length) {
      const debtor = debtors[dIdx];
      const creditor = creditors[cIdx];

      const settleAmount = Math.min(debtor.balance, creditor.balance);
      if (settleAmount > 0.01) {
        result.push({
          from: debtor.email,
          to: creditor.email,
          amount: Math.round(settleAmount * 100) / 100,
        });
      }

      debtor.balance -= settleAmount;
      creditor.balance -= settleAmount;

      if (debtor.balance < 0.01) dIdx++;
      if (creditor.balance < 0.01) cIdx++;
    }

    return result;
  }, [balances]);

  // 3. Render map node coordinate helpers
  const svgDimensions = { width: 540, height: 280 };
  const graphNodes = useMemo(() => {
    const list = Object.entries(balances).map(([email, balance]) => ({
      email,
      balance,
    }));

    const creditorsList = list.filter((n) => n.balance > 0.01).sort((a, b) => b.balance - a.balance);
    const debtorsList = list.filter((n) => n.balance < -0.01).sort((a, b) => a.balance - b.balance);
    const neutralList = list.filter((n) => Math.abs(n.balance) <= 0.01);

    const nodes: { [email: string]: { x: number; y: number; type: 'debtor' | 'creditor' | 'neutral' } } = {};

    // Position Debtors on Left (X = 80)
    debtorsList.forEach((n, i) => {
      const segment = svgDimensions.height / (debtorsList.length + 1);
      nodes[n.email] = {
        x: 80,
        y: segment * (i + 1),
        type: 'debtor',
      };
    });

    // Position Creditors on Right (X = 460)
    creditorsList.forEach((n, i) => {
      const segment = svgDimensions.height / (creditorsList.length + 1);
      nodes[n.email] = {
        x: 460,
        y: segment * (i + 1),
        type: 'creditor',
      };
    });

    // Position Neutrals in Middle Column (X = 270)
    neutralList.forEach((n, i) => {
      const segment = svgDimensions.height / (neutralList.length + 1);
      nodes[n.email] = {
        x: 270,
        y: segment * (i + 1),
        type: 'neutral',
      };
    });

    return nodes;
  }, [balances, svgDimensions.height]);

  const nameShortener = (email: string) => {
    const prefix = email.split('@')[0];
    return prefix.charAt(0).toUpperCase() + prefix.slice(1);
  };

  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-xs">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Zap className="h-5 w-5 text-emerald-500" />
            Debt Simplifier Engine
          </h3>
          <p className="text-sm text-gray-500">
            Minimizing transactions automatically using Greedy Graph Cycle reduction.
          </p>
        </div>
      </div>

      {transactions.length === 0 ? (
        <div className="text-center py-12 bg-gray-50/50 rounded-2xl border border-dashed border-gray-200">
          <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500 mb-3" />
          <p className="text-gray-900 font-medium">All settled up!</p>
          <p className="text-sm text-gray-500 mt-1">No outstanding balances or payments required for this group.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Dynamic Flow Map (SVG Viewport) */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center border border-gray-100 bg-gray-50/50 rounded-2xl p-4 relative overflow-hidden">
            <span className="absolute top-3 left-3 text-[10px] font-mono text-gray-400 bg-white px-2 py-0.5 rounded border border-gray-100 uppercase tracking-widest">
              Live Algorithmic Graph
            </span>

            <svg
              viewBox={`0 0 ${svgDimensions.width} ${svgDimensions.height}`}
              className="w-full max-w-xl h-auto"
            >
              <defs>
                <marker
                  id="arrow"
                  viewBox="0 0 10 10"
                  refX="18"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#10B981" />
                </marker>
                <marker
                  id="arrow-grey"
                  viewBox="0 0 10 10"
                  refX="18"
                  refY="5"
                  markerWidth="5"
                  markerHeight="5"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#9CA3AF" />
                </marker>
              </defs>

              {/* Draw transaction connecting paths */}
              {transactions.map((tx, idx) => {
                const start = graphNodes[tx.from];
                const end = graphNodes[tx.to];
                if (!start || !end) return null;

                // Create nice curved control points
                const dx = end.x - start.x;
                const dy = end.y - start.y;
                const cx = start.x + dx * 0.5;
                const cy = start.y + dy * 0.5 - Math.sin(idx) * 40; // curve offset

                return (
                  <g key={`flow-${idx}`}>
                    <path
                      d={`M ${start.x} ${start.y} Q ${cx} ${cy} ${end.x} ${end.y}`}
                      fill="none"
                      stroke="#10B981"
                      strokeWidth="2.5"
                      strokeDasharray="6,4"
                      className="animate-[dash_1s_linear_infinite]"
                      style={{
                        strokeDashoffset: -20,
                      }}
                      markerEnd="url(#arrow)"
                    />
                    {/* Amount badge on path */}
                    <rect
                      x={cx - 30}
                      y={cy - 10}
                      width="60"
                      height="18"
                      rx="9"
                      fill="#ffffff"
                      stroke="#E5E7EB"
                      strokeWidth="1"
                    />
                    <text
                      x={cx}
                      y={cy + 3}
                      fill="#047857"
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {currencySymbol}
                      {tx.amount}
                    </text>
                  </g>
                );
              })}

              {/* Draw Nodes */}
              {Object.entries(balances).map(([email, balance]) => {
                const node = graphNodes[email];
                if (!node) return null;

                const isDebtor = node.type === 'debtor';
                const isCreditor = node.type === 'creditor';

                let circleFill = 'fill-gray-100';
                let circleStroke = 'stroke-gray-300';
                let textFill = 'fill-gray-700';

                if (isDebtor) {
                  circleFill = 'fill-rose-50';
                  circleStroke = 'stroke-rose-500';
                  textFill = 'fill-rose-700';
                } else if (isCreditor) {
                  circleFill = 'fill-emerald-50';
                  circleStroke = 'stroke-emerald-500';
                  textFill = 'fill-emerald-700';
                }

                return (
                  <g key={`node-${email}`}>
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r="16"
                      className={`${circleFill} ${circleStroke}`}
                      strokeWidth="2"
                    />
                    <text
                      x={node.x}
                      y={node.y + 4}
                      className="text-[10px] font-bold text-center"
                      textAnchor="middle"
                      fill="#1F2937"
                    >
                      {nameShortener(email).substring(0, 2)}
                    </text>
                    {/* Full Name & Balance label */}
                    <text
                      x={node.x}
                      y={node.y - 20}
                      className="text-[10px] font-medium"
                      textAnchor="middle"
                      fill="#4B5563"
                    >
                      {nameShortener(email)}
                    </text>
                    <text
                      x={node.x}
                      y={node.y + 32}
                      className={`text-[9px] font-bold ${textFill}`}
                      textAnchor="middle"
                    >
                      {balance > 0 ? '+' : ''}
                      {currencySymbol}
                      {balance}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Quick Settlement Actions Panel */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wider">
                Optimized Settlement List
              </h4>

              <div className="space-y-3 max-h-[190px] overflow-y-auto pr-1">
                {transactions.map((tx, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center justify-between p-3.5 bg-gray-50 rounded-xl border border-gray-100 hover:border-gray-200 transition-all group"
                  >
                    <div className="flex items-center gap-2 max-w-[70%] truncate">
                      <div className="truncate">
                        <span className="font-semibold text-gray-900">
                          {nameShortener(tx.from)}
                        </span>
                        <span className="text-xs text-gray-500 block">owes</span>
                      </div>
                      <ArrowRight className="h-4 w-4 text-gray-400 group-hover:translate-x-1 transition-transform" />
                      <div className="truncate">
                        <span className="font-semibold text-gray-900">
                          {nameShortener(tx.to)}
                        </span>
                        <span className="text-xs text-gray-500 block">creditor</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-bold text-emerald-600 block">
                        {currencySymbol}
                        {tx.amount}
                      </span>
                      <button
                        onClick={() => onSettle(tx.from, tx.to, tx.amount)}
                        className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 hover:underline cursor-pointer flex items-center gap-1 justify-end mt-0.5"
                      >
                        <CheckCircle2 className="h-3 w-3" />
                        Settle Up
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-100">
              <div className="flex items-center gap-2 bg-blue-50/50 rounded-xl p-3 border border-blue-100">
                <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" style={{ animationDuration: '6s' }} />
                <span className="text-xs text-blue-800 font-medium">
                  Ledger simplifications updated automatically on every item split modification.
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
