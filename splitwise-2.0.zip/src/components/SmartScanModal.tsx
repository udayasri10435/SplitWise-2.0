import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Camera, Sliders, Image as ImageIcon, Sparkles, AlertTriangle, 
  Check, Edit3, Trash2, Plus, Loader2, ArrowRight, Eye 
} from 'lucide-react';
import { ReceiptItem } from '../types';

interface SmartScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: {
    title: string;
    items: { name: string; price: number; quantity: number }[];
    subtotal: number;
    tax: number;
    totalAmount: number;
  }) => void;
  isPro: boolean;
}

// Preset demo receipts so users don't necessarily have to upload a real crumpled receipt
const DEMO_RECEIPTS = [
  {
    name: "Cafe & Bar (Simple Qty split)",
    img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&q=80&w=400",
    mockData: {
      merchant: "The Green Tavern",
      items: [
        { name: "Pilsner Beer x 2", price: 8.00, quantity: 2, total: 16.00 },
        { name: "Guacamole & Chips", price: 14.50, quantity: 1, total: 14.50 },
        { name: "Wagyu Burger x 2", price: 22.00, quantity: 2, total: 44.00 },
        { name: "Artisanal Fries", price: 9.00, quantity: 1, total: 9.00 }
      ],
      subtotal: 83.50,
      tax: 6.50,
      totalAmount: 90.00,
      confidence: 96
    }
  },
  {
    name: "Dinner Bill (Multiple items)",
    img: "https://images.unsplash.com/photo-1543007630-9710e4a00a20?auto=format&fit=crop&q=80&w=400",
    mockData: {
      merchant: "Sunset Bistro",
      items: [
        { name: "Red Wine Glass x 3", price: 12.00, quantity: 3, total: 36.00 },
        { name: "Ribeye Steak", price: 34.00, quantity: 1, total: 34.00 },
        { name: "Grilled Salmon", price: 28.00, quantity: 1, total: 28.00 },
        { name: "Truffle Pasta", price: 24.00, quantity: 1, total: 24.00 }
      ],
      subtotal: 122.00,
      tax: 11.00,
      totalAmount: 133.00,
      confidence: 76 // Low confidence triggers review highlighting
    }
  }
];

export const SmartScanModal: React.FC<SmartScanModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  isPro,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Upload & Filter, 2: Scanning, 3: Review/Ambiguity UI
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [contrast, setContrast] = useState<number>(1.2);
  const [brightness, setBrightness] = useState<number>(1.0);
  const [grayscale, setGrayscale] = useState<boolean>(true);
  const [straighten, setStraighten] = useState<number>(0); // Rotation degrees
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanError, setScanError] = useState<string | null>(null);

  // Parsed outputs (Editable)
  const [parsedMerchant, setParsedMerchant] = useState<string>('');
  const [parsedItems, setParsedItems] = useState<{ name: string; price: number; quantity: number }[]>([]);
  const [parsedSubtotal, setParsedSubtotal] = useState<number>(0);
  const [parsedTax, setParsedTax] = useState<number>(0);
  const [parsedTotal, setParsedTotal] = useState<number>(0);
  const [parsedConfidence, setParsedConfidence] = useState<number>(90);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const originalImageRef = useRef<HTMLImageElement | null>(null);

  // Standard Image Chef Pre-Processor
  useEffect(() => {
    if (!selectedImage) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      originalImageRef.current = img;
      applyImageChefFilters();
    };
    img.src = selectedImage;
  }, [selectedImage, contrast, brightness, grayscale, straighten]);

  const applyImageChefFilters = () => {
    const img = originalImageRef.current;
    const canvas = canvasRef.current;
    if (!img || !canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions with rotation consideration
    const angleRad = (straighten * Math.PI) / 180;
    const absCos = Math.abs(Math.cos(angleRad));
    const absSin = Math.abs(Math.sin(angleRad));

    const destWidth = Math.round(img.width * absCos + img.height * absSin);
    const destHeight = Math.round(img.width * absSin + img.height * absCos);

    // Keep dimensions bounded for fast client-side pixel loop processing
    const maxDimension = 800;
    let finalWidth = destWidth;
    let finalHeight = destHeight;

    if (destWidth > maxDimension || destHeight > maxDimension) {
      const scale = maxDimension / Math.max(destWidth, destHeight);
      finalWidth = Math.round(destWidth * scale);
      finalHeight = Math.round(destHeight * scale);
    }

    canvas.width = finalWidth;
    canvas.height = finalHeight;

    // Center and rotate
    ctx.translate(finalWidth / 2, finalHeight / 2);
    ctx.rotate(angleRad);
    
    // Draw scaled image centered
    const scaleFactor = Math.min(finalWidth / destWidth, finalHeight / destHeight);
    const drawWidth = img.width * scaleFactor;
    const drawHeight = img.height * scaleFactor;
    ctx.drawImage(img, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);

    // Apply Contrast, Grayscale, and Brightness
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = imgData.data;

    for (let i = 0; i < d.length; i += 4) {
      let r = d[i];
      let g = d[i+1];
      let b = d[i+2];

      // Grayscale
      if (grayscale) {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = g = b = gray;
      }

      // Brightness
      r = Math.min(255, Math.max(0, r * brightness));
      g = Math.min(255, Math.max(0, g * brightness));
      b = Math.min(255, Math.max(0, b * brightness));

      // Contrast
      r = Math.min(255, Math.max(0, (r - 128) * contrast + 128));
      g = Math.min(255, Math.max(0, (g - 128) * contrast + 128));
      b = Math.min(255, Math.max(0, (b - 128) * contrast + 128));

      d[i] = r;
      d[i+1] = g;
      d[i+2] = b;
    }

    ctx.putImageData(imgData, 0, 0);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
      setStep(1);
    };
    reader.readAsDataURL(file);
  };

  const triggerScan = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsScanning(true);
    setStep(2);
    setScanError(null);

    try {
      const base64Image = canvas.toDataURL('image/jpeg', 0.85);

      const response = await fetch('/api/scan-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64Image,
          isPro,
        }),
      });

      if (!response.ok) {
        throw new Error(`OCR processing failed: ${response.statusText}`);
      }

      const data = await response.json();

      // Check "The Grouping Hack" / Multiple Quantities automatically processed by backend
      // But verify structures on client
      const items = (data.items || []).map((it: any) => ({
        name: it.name || 'Unlabeled Item',
        price: Number(it.price) || 0,
        quantity: Number(it.quantity) || 1,
      }));

      // Set items
      const expandedItems: any[] = [];
      items.forEach((it: any) => {
        if (it.quantity > 1) {
          // Explode the lines so they can be separate entities for assignees
          for (let q = 0; q < it.quantity; q++) {
            expandedItems.push({
              name: `${it.name} [Split ${q + 1}]`,
              price: Number((it.price / 1).toFixed(2)), // Individual price
              quantity: 1
            });
          }
        } else {
          expandedItems.push(it);
        }
      });

      setParsedMerchant(data.merchant || 'Retailer Receipt');
      setParsedItems(expandedItems);
      setParsedSubtotal(Number(data.subtotal) || Number(data.totalAmount) || 0);
      setParsedTax(Number(data.tax) || 0);
      setParsedTotal(Number(data.totalAmount) || Number(data.subtotal) || 0);
      setParsedConfidence(data.confidence || 85);

      setStep(3);
    } catch (error: any) {
      console.error(error);
      setScanError(error.message || 'Error occurred scanning image.');
      setStep(1);
    } finally {
      setIsScanning(false);
    }
  };

  // Skip scan to Demo data directly
  const useDemoReceipt = (demo: typeof DEMO_RECEIPTS[0]) => {
    setSelectedImage(demo.img);
    setParsedMerchant(demo.mockData.merchant);
    
    // Auto-explode demo quantity splits
    const expanded: any[] = [];
    demo.mockData.items.forEach((it) => {
      if (it.quantity > 1) {
        for (let q = 0; q < it.quantity; q++) {
          expanded.push({
            name: `${it.name.split(' x ')[0]} [Part ${q+1}]`,
            price: it.price, // divided already or unit price
            quantity: 1
          });
        }
      } else {
        expanded.push(it);
      }
    });

    setParsedItems(expanded);
    setParsedSubtotal(demo.mockData.subtotal);
    setParsedTax(demo.mockData.tax);
    setParsedTotal(demo.mockData.totalAmount);
    setParsedConfidence(demo.mockData.confidence);
    setStep(3);
  };

  // Editing logic in Ambiguity UI
  const handleItemChange = (index: number, field: 'name' | 'price', value: string) => {
    const updated = [...parsedItems];
    if (field === 'price') {
      updated[index].price = parseFloat(value) || 0;
    } else {
      updated[index].name = value;
    }
    setParsedItems(updated);

    // Recalculate Subtotal & Total
    const sub = updated.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
    setParsedSubtotal(Number(sub.toFixed(2)));
    setParsedTotal(Number((sub + parsedTax).toFixed(2)));
  };

  const deleteItem = (index: number) => {
    const updated = parsedItems.filter((_, i) => i !== index);
    setParsedItems(updated);
    const sub = updated.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
    setParsedSubtotal(Number(sub.toFixed(2)));
    setParsedTotal(Number((sub + parsedTax).toFixed(2)));
  };

  const addNewItem = () => {
    setParsedItems([...parsedItems, { name: 'New Item', price: 0.0, quantity: 1 }]);
  };

  const handleTaxChange = (val: string) => {
    const t = parseFloat(val) || 0;
    setParsedTax(t);
    setParsedTotal(Number((parsedSubtotal + t).toFixed(2)));
  };

  const handleFinish = () => {
    onConfirm({
      title: parsedMerchant,
      items: parsedItems,
      subtotal: parsedSubtotal,
      tax: parsedTax,
      totalAmount: parsedTotal,
    });
    // Reset state
    setSelectedImage(null);
    setStep(1);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl shadow-xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
            <div className="flex items-center gap-2.5">
              <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-500/10">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 flex items-center gap-1.5">
                  Smart Scan OCR Pipeline
                  {isPro ? (
                    <span className="text-[10px] bg-emerald-500 text-white font-extrabold px-1.5 py-0.5 rounded-sm uppercase tracking-widest">
                      Gemini Pro
                    </span>
                  ) : (
                    <span className="text-[10px] bg-blue-500 text-white font-extrabold px-1.5 py-0.5 rounded-sm uppercase tracking-widest">
                      Flash
                    </span>
                  )}
                </h2>
                <p className="text-xs text-gray-500">
                  Pre-processes receipts using client-side shaders then splits entities with generative AI.
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto p-6">
            {step === 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Image Input & Canvas */}
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-gray-200 bg-gray-50/50 rounded-2xl p-6 min-h-[320px] relative overflow-hidden group">
                  {selectedImage ? (
                    <div className="relative w-full h-full flex flex-col items-center justify-center">
                      <canvas
                        ref={canvasRef}
                        className="max-h-[260px] max-w-full rounded-lg shadow-md border border-gray-100 object-contain bg-white"
                      />
                      <button
                        onClick={() => setSelectedImage(null)}
                        className="mt-3 text-xs text-rose-500 font-semibold hover:underline cursor-pointer"
                      >
                        Change Image
                      </button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <ImageIcon className="mx-auto h-12 w-12 text-gray-400 mb-3 group-hover:scale-115 transition-transform duration-300" />
                      <p className="text-sm font-semibold text-gray-900">Upload Receipt Photo</p>
                      <p className="text-xs text-gray-500 mt-1 mb-4">Accepts PNG, JPG, or Live Capture</p>
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5 mx-auto"
                      >
                        <Camera className="h-4 w-4" />
                        Choose Photo
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />

                      {/* Demo suggestions */}
                      <div className="mt-8 border-t border-gray-100 pt-4">
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-3">
                          Quick Demo Mock receipts
                        </span>
                        <div className="flex flex-col gap-2.5">
                          {DEMO_RECEIPTS.map((demo, idx) => (
                            <button
                              key={idx}
                              onClick={() => useDemoReceipt(demo)}
                              className="flex items-center gap-3 p-2 bg-white hover:bg-emerald-50 border border-gray-100 hover:border-emerald-200 rounded-xl transition-all text-left group/btn cursor-pointer"
                            >
                              <img
                                src={demo.img}
                                alt="Demo"
                                className="w-10 h-10 object-cover rounded-lg border border-gray-100"
                              />
                              <div>
                                <span className="text-xs font-semibold text-gray-800 block group-hover/btn:text-emerald-700">
                                  {demo.name}
                                </span>
                                <span className="text-[10px] text-gray-400 flex items-center gap-1">
                                  <Eye className="h-3 w-3" /> Click to load instantly
                                </span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {scanError && (
                    <div className="absolute bottom-2 left-2 right-2 bg-rose-50 text-rose-700 text-xs p-2 rounded-lg border border-rose-100 flex items-center gap-1.5">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      <span>{scanError}</span>
                    </div>
                  )}
                </div>

                {/* Pre-Processing (The Image Chef controls) */}
                <div className="flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider flex items-center gap-1.5 mb-4">
                      <Sliders className="h-4 w-4 text-emerald-500" />
                      Image Chef Shaders
                    </h3>

                    <div className="space-y-5">
                      {/* Contrast */}
                      <div>
                        <div className="flex justify-between text-xs font-medium text-gray-500 mb-1.5">
                          <span>Grayscale Enhancement</span>
                          <span className="font-semibold text-emerald-600">
                            {grayscale ? 'ENABLED (Optimal)' : 'DISABLED'}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => setGrayscale(!grayscale)}
                            className={`w-full py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                              grayscale
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-gray-50 text-gray-500 border-gray-200 hover:bg-gray-100'
                            }`}
                          >
                            {grayscale ? 'Grayscale Shader: Active' : 'Grayscale Shader: Inactive'}
                          </button>
                        </div>
                      </div>

                      {/* Contrast Adjustment */}
                      <div>
                        <div className="flex justify-between text-xs font-medium text-gray-500 mb-1.5">
                          <span>Edge Contrast Booster</span>
                          <span className="font-semibold text-gray-800">{contrast.toFixed(1)}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.5"
                          max="2.5"
                          step="0.1"
                          value={contrast}
                          onChange={(e) => setContrast(parseFloat(e.target.value))}
                          className="w-full accent-emerald-500"
                        />
                        <p className="text-[10px] text-gray-400 mt-1">
                          Sharpen receipt characters before sending to ML API.
                        </p>
                      </div>

                      {/* Straighten Rotation */}
                      <div>
                        <div className="flex justify-between text-xs font-medium text-gray-500 mb-1.5">
                          <span>Deskew Rotation Angle</span>
                          <span className="font-semibold text-gray-800">{straighten}°</span>
                        </div>
                        <input
                          type="range"
                          min="-45"
                          max="45"
                          step="1"
                          value={straighten}
                          onChange={(e) => setStraighten(parseInt(e.target.value))}
                          className="w-full accent-emerald-500"
                        />
                        <p className="text-[10px] text-gray-400 mt-1">
                          Straighten rotated bills to increase parser recognition by 40%.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-100">
                    <button
                      onClick={triggerScan}
                      disabled={!selectedImage || isScanning}
                      className="w-full py-3 rounded-xl bg-gray-900 hover:bg-gray-800 disabled:bg-gray-100 disabled:text-gray-400 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>Trigger OCR Parser</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="flex flex-col items-center justify-center py-16">
                <div className="relative mb-6">
                  <div className="h-16 w-16 rounded-full border-4 border-emerald-100 border-t-emerald-500 animate-spin flex items-center justify-center" />
                  <Sparkles className="h-6 w-6 text-emerald-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-pulse" />
                </div>
                <h3 className="text-base font-bold text-gray-900">Scanning Receipt Image...</h3>
                <p className="text-xs text-gray-500 text-center max-w-sm mt-1.5 leading-relaxed">
                  The model is reading merchant text, grouping item tags, and resolving multi-quantities into single splits.
                </p>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                {/* Confidence & Warning */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <div className="flex items-center gap-2.5">
                    <div className={`h-8 w-8 rounded-lg flex items-center justify-center text-white ${
                      parsedConfidence >= 80 ? 'bg-emerald-500' : 'bg-amber-500'
                    }`}>
                      <span className="text-xs font-bold">{parsedConfidence}%</span>
                    </div>
                    <div>
                      <span className="text-xs text-gray-500 block font-medium">Confidence Rating</span>
                      <span className="text-xs font-bold text-gray-900">
                        {parsedConfidence >= 80 
                          ? 'Highly accurate parsing output' 
                          : 'Ambiguities detected. Please double-check items below.'}
                      </span>
                    </div>
                  </div>

                  {parsedConfidence < 80 && (
                    <div className="flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-100">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      <span>Review Suggested</span>
                    </div>
                  )}
                </div>

                {/* Merchant Name */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider md:text-right">
                    Merchant name
                  </label>
                  <input
                    type="text"
                    value={parsedMerchant}
                    onChange={(e) => setParsedMerchant(e.target.value)}
                    className="md:col-span-2 px-4 py-2.5 bg-white border border-gray-200 rounded-xl focus:border-emerald-500 focus:outline-hidden font-semibold text-gray-800 text-sm"
                  />
                </div>

                {/* Line Items Editable Table */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                      Extracted Line Items (Auto-split Qty)
                    </h4>
                    <button
                      onClick={addNewItem}
                      className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" /> Add Row
                    </button>
                  </div>

                  <div className="border border-gray-100 rounded-2xl overflow-hidden divide-y divide-gray-50">
                    {parsedItems.map((item, index) => (
                      <div
                        key={index}
                        className={`p-3 grid grid-cols-12 gap-3 items-center hover:bg-gray-50 transition-colors ${
                          parsedConfidence < 80 && item.price === 0 ? 'bg-amber-50/50' : 'bg-white'
                        }`}
                      >
                        {/* Name */}
                        <div className="col-span-7 flex items-center gap-2">
                          <span className="text-xs font-semibold text-gray-400 w-5">{index + 1}</span>
                          <input
                            type="text"
                            value={item.name}
                            onChange={(e) => handleItemChange(index, 'name', e.target.value)}
                            className="w-full bg-transparent border-0 focus:ring-0 focus:outline-hidden p-0 font-medium text-gray-800 text-sm"
                          />
                        </div>

                        {/* Price */}
                        <div className="col-span-4 flex items-center gap-1 bg-gray-50 px-2 py-1 rounded-lg border border-gray-100">
                          <span className="text-xs text-gray-400 font-bold">$</span>
                          <input
                            type="number"
                            step="0.01"
                            value={item.price}
                            onChange={(e) => handleItemChange(index, 'price', e.target.value)}
                            className="w-full bg-transparent border-0 focus:ring-0 focus:outline-hidden p-0 font-bold text-gray-800 text-sm text-right"
                          />
                        </div>

                        {/* Delete button */}
                        <div className="col-span-1 text-right">
                          <button
                            onClick={() => deleteItem(index)}
                            className="p-1 text-gray-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Subtotals & Tax */}
                <div className="border-t border-gray-100 pt-5 grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50/30 p-5 rounded-2xl">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500 font-semibold uppercase">Subtotal</span>
                      <span className="text-sm font-bold text-gray-800">${parsedSubtotal.toFixed(2)}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500 font-semibold uppercase">Sales Tax / Tips</span>
                      <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-lg px-2 py-1 max-w-[120px]">
                        <span className="text-xs text-gray-400 font-bold">$</span>
                        <input
                          type="number"
                          step="0.01"
                          value={parsedTax}
                          onChange={(e) => handleTaxChange(e.target.value)}
                          className="w-full bg-transparent border-0 focus:ring-0 focus:outline-hidden p-0 text-sm font-bold text-gray-800 text-right"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-center items-end bg-emerald-50 rounded-xl p-4 border border-emerald-100">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-widest">
                      Total Ledger Amount
                    </span>
                    <span className="text-2xl font-extrabold text-emerald-700 mt-1">
                      ${parsedTotal.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Footer confirm */}
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                  >
                    Back to Scan Adjustments
                  </button>
                  <button
                    onClick={handleFinish}
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Check className="h-4 w-4" />
                    Import to Group Ledger
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
