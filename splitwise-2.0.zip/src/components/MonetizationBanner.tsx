import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Zap, Sparkles, CreditCard, ChevronRight, CheckCircle2, User, Landmark, HelpCircle } from 'lucide-react';

interface MonetizationBannerProps {
  isPro: boolean;
  onTogglePro: () => void;
  scansCount: number;
}

export const MonetizationBanner: React.FC<MonetizationBannerProps> = ({
  isPro,
  onTogglePro,
  scansCount,
}) => {
  const freeScansLimit = 5;
  const remainingScans = Math.max(0, freeScansLimit - scansCount);

  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-xs relative overflow-hidden">
      {/* Background decoration elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full blur-2xl opacity-40 -translate-y-12 translate-x-12" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-50 rounded-full blur-xl opacity-30 translate-y-8 -translate-x-8" />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
              isPro 
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                : 'bg-blue-50 text-blue-700 border border-blue-200'
            }`}>
              {isPro ? 'Pro Account' : 'Free Tier Account'}
            </span>
            {!isPro && (
              <span className="text-[10px] text-gray-500 font-medium">
                {remainingScans} of {freeScansLimit} free OCR scans remaining
              </span>
            )}
          </div>

          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-1.5">
            {isPro ? 'SplitWise Pro Active' : 'Upgrade to SplitWise 2.0 Pro'}
            <Sparkles className="h-4 w-4 text-amber-500 animate-pulse" />
          </h3>
          <p className="text-xs text-gray-500 max-w-xl mt-1 leading-relaxed">
            {isPro 
              ? 'Enjoy priority AI parser pipelines (Gemini Pro), unlimited scans, full visual analytics, and immediate bank settle-ups via Stripe Connect/Plaid.'
              : 'Unlock priority OCR engines, unlimited receipt scans, full spend analytics, and eliminate standard 3-day wait times with instant bank payouts.'}
          </p>

          {/* Quick status dots */}
          <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-3.5">
            <div className="flex items-center gap-1.5 text-xs text-gray-600 font-medium">
              <CheckCircle2 className={`h-4 w-4 ${isPro ? 'text-emerald-500' : 'text-gray-300'}`} />
              <span>Priority Gemini Pro OCR</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-gray-600 font-medium">
              <CheckCircle2 className={`h-4 w-4 ${isPro ? 'text-emerald-500' : 'text-gray-300'}`} />
              <span>Unlimited Receipt Scans</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-gray-600 font-medium">
              <CheckCircle2 className={`h-4 w-4 ${isPro ? 'text-emerald-500' : 'text-gray-300'}`} />
              <span>Instant Bank Settle-Ups (Plaid)</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-stretch sm:items-end justify-center shrink-0 min-w-[200px]">
          {isPro ? (
            <button
              onClick={onTogglePro}
              className="px-4 py-2.5 bg-gray-50 hover:bg-gray-100 text-gray-700 font-bold text-xs rounded-xl border border-gray-200 transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5"
            >
              <User className="h-4 w-4" />
              Switch back to Free
            </button>
          ) : (
            <button
              onClick={onTogglePro}
              className="px-5 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/15 transition-all cursor-pointer flex items-center justify-center gap-2 group text-center"
            >
              <Zap className="h-4 w-4 text-amber-300 group-hover:scale-120 transition-transform" />
              <span>Upgrade ($4.99/mo)</span>
              <ChevronRight className="h-4 w-4" />
            </button>
          )}

          <div className="text-center sm:text-right mt-2 flex items-center gap-1 justify-center sm:justify-end text-[10px] text-gray-400 font-medium">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
            <span>Secure 256-bit encrypted transactions</span>
          </div>
        </div>
      </div>

      {/* Instant Settlement info block (Plaid/Stripe Connect simulator) */}
      {isPro && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-5 pt-4 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-emerald-50/40 p-4 rounded-xl border border-emerald-100/50"
        >
          <div className="flex items-start gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0 mt-0.5">
              <Landmark className="h-4 w-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-800 block">Stripe Connect & Plaid Linked Successfully</span>
              <span className="text-[10px] text-emerald-600">
                ACH settlement delays are bypassed. Receipts settled in this group are processed instantly through Federal Liquidity reserve APIs.
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0 bg-white border border-emerald-200 text-[10px] font-bold text-emerald-700 px-2 py-1 rounded-lg">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>DIRECT PAY DEPLOYED</span>
          </div>
        </motion.div>
      )}
    </div>
  );
};
