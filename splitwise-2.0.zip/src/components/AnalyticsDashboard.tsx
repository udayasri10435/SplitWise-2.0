import React, { useMemo } from 'react';
import { Group, Expense } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { motion } from 'motion/react';
import { TrendingUp, PieChart as PieIcon, Award, DollarSign, Sparkles, UserCheck } from 'lucide-react';

interface AnalyticsDashboardProps {
  group: Group;
  expenses: Expense[];
  currencySymbol: string;
}

const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

// Categorize items dynamically based on name keywords
const getCategoryFromItemName = (name: string): string => {
  const n = name.toLowerCase();
  if (
    n.includes('beer') || n.includes('wine') || n.includes('ipa') || 
    n.includes('cocktail') || n.includes('drink') || n.includes('gin') || 
    n.includes('margarita') || n.includes('shot') || n.includes('alcohol') || 
    n.includes('sake') || n.includes('whiskey') || n.includes('beverage')
  ) {
    return 'Alcohol';
  }
  if (
    n.includes('burger') || n.includes('steak') || n.includes('pasta') || 
    n.includes('salad') || n.includes('pizza') || n.includes('sandwich') || 
    n.includes('entree') || n.includes('chicken') || n.includes('beef') || 
    n.includes('salmon') || n.includes('taco') || n.includes('ribs') ||
    n.includes('bistro') || n.includes('dining') || n.includes('fish')
  ) {
    return 'Main Entree';
  }
  if (
    n.includes('fries') || n.includes('chips') || n.includes('nachos') || 
    n.includes('onion') || n.includes('truffle') || n.includes('bread') || 
    n.includes('wings') || n.includes('mozzarella') || n.includes('soup') ||
    n.includes('appetizer') || n.includes('starter')
  ) {
    return 'Sides & Apps';
  }
  if (
    n.includes('cake') || n.includes('ice') || n.includes('dessert') || 
    n.includes('pudding') || n.includes('waffle') || n.includes('chocolate') || 
    n.includes('pie') || n.includes('sweet') || n.includes('cookie')
  ) {
    return 'Desserts';
  }
  return 'General Ledger';
};

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  group,
  expenses,
  currencySymbol,
}) => {
  const activeExpenses = useMemo(() => expenses.filter((e) => !e.deletedAt), [expenses]);

  // 1. Calculate general overview stats
  const totalGroupSpent = useMemo(() => {
    return activeExpenses.reduce((sum, e) => sum + e.totalAmount, 0);
  }, [activeExpenses]);

  // 2. Member Spend breakdown data
  const memberSpendData = useMemo(() => {
    const list: { [email: string]: { paid: number; owed: number } } = {};
    group.members.forEach((email) => {
      list[email] = { paid: 0, owed: 0 };
    });

    activeExpenses.forEach((expense) => {
      const payer = expense.paidBy;
      if (group.members.includes(payer)) {
        list[payer].paid += expense.totalAmount;
      }

      if (expense.items && expense.items.length > 0) {
        // Itemized breakdown
        const itemOwes: { [email: string]: number } = {};
        group.members.forEach((m) => { itemOwes[m] = 0; });
        let totalAssignedCost = 0;

        expense.items.forEach((item) => {
          const assignees = item.assignedTo && item.assignedTo.length > 0 ? item.assignedTo : group.members;
          const share = item.price / assignees.length;
          assignees.forEach((email) => {
            if (group.members.includes(email)) {
              itemOwes[email] += share;
              totalAssignedCost += share;
            }
          });
        });

        const overhead = expense.totalAmount - totalAssignedCost;
        group.members.forEach((email) => {
          let share = 0;
          if (totalAssignedCost > 0) {
            share = itemOwes[email] + (overhead * (itemOwes[email] / totalAssignedCost));
          } else {
            share = expense.totalAmount / group.members.length;
          }
          list[email].owed += share;
        });
      } else {
        // Simple equal split
        const share = expense.totalAmount / group.members.length;
        group.members.forEach((email) => {
          list[email].owed += share;
        });
      }
    });

    return Object.entries(list).map(([email, stats]) => ({
      name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
      Paid: Number(stats.paid.toFixed(2)),
      Owed: Number(stats.owed.toFixed(2)),
    }));
  }, [group, activeExpenses]);

  // 3. Category Breakdown data
  const categoryData = useMemo(() => {
    const categories: { [cat: string]: number } = {
      'Alcohol': 0,
      'Main Entree': 0,
      'Sides & Apps': 0,
      'Desserts': 0,
      'General Ledger': 0
    };

    activeExpenses.forEach((expense) => {
      if (expense.items && expense.items.length > 0) {
        expense.items.forEach((item) => {
          const cat = getCategoryFromItemName(item.name);
          categories[cat] += item.price;
        });
        // Allocate any missing/tax/fees to General Ledger
        const totalItemsPrice = expense.items.reduce((sum, i) => sum + i.price, 0);
        const diff = expense.totalAmount - totalItemsPrice;
        if (diff > 0) {
          categories['General Ledger'] += diff;
        }
      } else {
        // Categorize whole expense from its title
        const cat = getCategoryFromItemName(expense.title);
        categories[cat] += expense.totalAmount;
      }
    });

    return Object.entries(categories)
      .map(([name, value]) => ({
        name,
        value: Number(value.toFixed(2)),
      }))
      .filter((c) => c.value > 0);
  }, [activeExpenses]);

  // 4. "Who's the Glutton?" Spotlight
  const gluttonSpotlight = useMemo(() => {
    const memberCatSpend: { [email: string]: { [cat: string]: number } } = {};
    group.members.forEach((email) => {
      memberCatSpend[email] = {
        'Alcohol': 0,
        'Main Entree': 0,
        'Sides & Apps': 0,
        'Desserts': 0,
        'General Ledger': 0
      };
    });

    activeExpenses.forEach((expense) => {
      if (expense.items && expense.items.length > 0) {
        expense.items.forEach((item) => {
          const cat = getCategoryFromItemName(item.name);
          const assignees = item.assignedTo && item.assignedTo.length > 0 ? item.assignedTo : group.members;
          const share = item.price / assignees.length;
          assignees.forEach((email) => {
            if (group.members.includes(email)) {
              memberCatSpend[email][cat] += share;
            }
          });
        });
      } else {
        // Simple Split
        const cat = getCategoryFromItemName(expense.title);
        const share = expense.totalAmount / group.members.length;
        group.members.forEach((email) => {
          memberCatSpend[email][cat] += share;
        });
      }
    });

    // Find the person with the maximum spend in "Alcohol" and "Dessert"
    let topAlcoholSpender = '';
    let topAlcoholAmount = 0;
    let topDessertSpender = '';
    let topDessertAmount = 0;
    let topSidesSpender = '';
    let topSidesAmount = 0;

    Object.entries(memberCatSpend).forEach(([email, cats]) => {
      if (cats['Alcohol'] > topAlcoholAmount) {
        topAlcoholAmount = cats['Alcohol'];
        topAlcoholSpender = email;
      }
      if (cats['Desserts'] > topDessertAmount) {
        topDessertAmount = cats['Desserts'];
        topDessertSpender = email;
      }
      if (cats['Sides & Apps'] > topSidesAmount) {
        topSidesAmount = cats['Sides & Apps'];
        topSidesSpender = email;
      }
    });

    const formatName = (email: string) => {
      if (!email) return 'N/A';
      const name = email.split('@')[0];
      return name.charAt(0).toUpperCase() + name.slice(1);
    };

    return {
      alcohol: {
        user: formatName(topAlcoholSpender),
        amount: Number(topAlcoholAmount.toFixed(2)),
        label: "The Beer Champion"
      },
      dessert: {
        user: formatName(topDessertSpender),
        amount: Number(topDessertAmount.toFixed(2)),
        label: "The Sweet Tooth"
      },
      sides: {
        user: formatName(topSidesSpender),
        amount: Number(topSidesAmount.toFixed(2)),
        label: "The App Addict"
      }
    };
  }, [group, activeExpenses]);

  return (
    <div className="space-y-8">
      {/* Overview stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-gray-100 rounded-2xl p-5 shadow-xs flex items-center gap-4"
        >
          <div className="h-12 w-12 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
            <DollarSign className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase tracking-wider block">Total Ledger Spend</span>
            <span className="text-xl font-black text-gray-900">
              {currencySymbol}
              {totalGroupSpent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white border border-gray-100 rounded-2xl p-5 shadow-xs flex items-center gap-4"
        >
          <div className="h-12 w-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
            <TrendingUp className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase tracking-wider block">Receipts Count</span>
            <span className="text-xl font-black text-gray-900">{activeExpenses.length} files scanned</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white border border-gray-100 rounded-2xl p-5 shadow-xs flex items-center gap-4"
        >
          <div className="h-12 w-12 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
            <UserCheck className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs text-gray-400 font-bold uppercase tracking-wider block">Group Members</span>
            <span className="text-xl font-black text-gray-900">{group.members.length} registered</span>
          </div>
        </motion.div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Paid vs Owed Bar Chart */}
        <div className="lg:col-span-7 bg-white border border-gray-100 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <UserCheck className="h-5 w-5 text-emerald-500" />
              Member Ledger: Paid vs. Owed
            </h3>
            <p className="text-xs text-gray-500">
              Funding advanced upfront (Paid) compared to fair item share consumption (Owed).
            </p>
          </div>

          <div className="h-[260px] w-full">
            {memberSpendData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={memberSpendData}
                  margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F3F4F6" />
                  <XAxis dataKey="name" fontSize={11} stroke="#9CA3AF" tickLine={false} />
                  <YAxis fontSize={11} stroke="#9CA3AF" tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#FFF', borderRadius: '12px', border: '1px solid #E5E7EB' }}
                    formatter={(value) => [`${currencySymbol}${value}`, '']}
                  />
                  <Legend verticalAlign="top" height={36} iconType="circle" iconSize={8} />
                  <Bar dataKey="Paid" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Owed" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-gray-400 font-mono">
                No ledger records found
              </div>
            )}
          </div>
        </div>

        {/* Categories Breakdown */}
        <div className="lg:col-span-5 bg-white border border-gray-100 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div className="mb-4">
            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
              <PieIcon className="h-5 w-5 text-blue-500" />
              Category Allocations
            </h3>
            <p className="text-xs text-gray-500">
              Categorized spending derived dynamically from item tag parsing.
            </p>
          </div>

          <div className="h-[210px] w-full flex items-center justify-center">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${currencySymbol}${value}`, '']} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-xs text-gray-400 font-mono">No categories loaded</div>
            )}
          </div>

          {/* Color Indicators Legend */}
          <div className="grid grid-cols-3 gap-2 mt-2">
            {categoryData.map((entry, idx) => (
              <div key={idx} className="flex items-center gap-1.5 truncate">
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                />
                <span className="text-[10px] text-gray-500 font-medium truncate">
                  {entry.name} ({currencySymbol}{entry.value})
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* "Who's the Glutton?" Spotlight Dashboard Block */}
      <div className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-950 rounded-3xl p-6 text-white relative overflow-hidden shadow-lg shadow-gray-950/20">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Award className="h-44 w-44" />
        </div>

        <div className="flex items-center gap-2 mb-6">
          <div className="h-8 w-8 rounded-lg bg-emerald-500 flex items-center justify-center text-white">
            <Award className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-base font-bold flex items-center gap-1.5">
              Social Spending Spotlight: Who's the Glutton?
              <Sparkles className="h-4 w-4 text-emerald-400 animate-pulse" />
            </h3>
            <p className="text-xs text-gray-400">
              Aggregated social indexes highlighting spending behaviors within the ledger.
            </p>
          </div>
        </div>

        {totalGroupSpent === 0 ? (
          <p className="text-xs text-gray-400 font-mono italic">Spotlight updates once items are cataloged in expenses.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Alcohol glutton */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block mb-1">
                {gluttonSpotlight.alcohol.label}
              </span>
              <span className="text-lg font-bold block truncate">
                {gluttonSpotlight.alcohol.amount > 0 ? gluttonSpotlight.alcohol.user : 'N/A'}
              </span>
              <div className="flex justify-between items-center mt-3 text-xs text-gray-400 border-t border-white/5 pt-2">
                <span>Consumed:</span>
                <span className="font-bold text-emerald-400">
                  {currencySymbol}
                  {gluttonSpotlight.alcohol.amount}
                </span>
              </div>
            </div>

            {/* Desserts glutton */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5">
              <span className="text-[10px] font-bold text-pink-400 uppercase tracking-widest block mb-1">
                {gluttonSpotlight.dessert.label}
              </span>
              <span className="text-lg font-bold block truncate">
                {gluttonSpotlight.dessert.amount > 0 ? gluttonSpotlight.dessert.user : 'N/A'}
              </span>
              <div className="flex justify-between items-center mt-3 text-xs text-gray-400 border-t border-white/5 pt-2">
                <span>Consumed:</span>
                <span className="font-bold text-emerald-400">
                  {currencySymbol}
                  {gluttonSpotlight.dessert.amount}
                </span>
              </div>
            </div>

            {/* Sides glutton */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4.5">
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest block mb-1">
                {gluttonSpotlight.sides.label}
              </span>
              <span className="text-lg font-bold block truncate">
                {gluttonSpotlight.sides.amount > 0 ? gluttonSpotlight.sides.user : 'N/A'}
              </span>
              <div className="flex justify-between items-center mt-3 text-xs text-gray-400 border-t border-white/5 pt-2">
                <span>Consumed:</span>
                <span className="font-bold text-emerald-400">
                  {currencySymbol}
                  {gluttonSpotlight.sides.amount}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
