export interface Group {
  id: string;
  name: string;
  description: string;
  members: string[]; // List of member names/emails
  createdAt: any; // Firestore Timestamp or Date string
  createdBy: string; // Creator's auth UID
  currency: string; // EUR, USD, GBP, JPY, etc.
}

export interface ReceiptItem {
  id: string;
  name: string;
  price: number;
  assignedTo: string[]; // emails of group members assigned to this item
}

export interface Expense {
  id: string;
  groupId: string;
  title: string;
  paidBy: string; // email of the paying member
  totalAmount: number;
  subtotal: number;
  tax: number;
  items: ReceiptItem[];
  createdAt: any;
  updatedAt: any;
  deletedAt: string | null; // ISO string if soft-deleted, or null
  receiptUrl?: string | null;
}

export interface ActivityLog {
  id: string;
  groupId: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  createdAt: any;
}

export interface ExchangeRates {
  base: string;
  rates: {
    [currency: string]: number;
  };
}
