/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { 
  Plus, Users, DollarSign, ArrowLeft, LogOut, Trash2, Calendar, 
  Sparkles, ListCollapse, Share2, ClipboardList, Info, Layers, RefreshCcw, 
  HelpCircle, UserPlus, Check, Play, User, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  collection, query, where, onSnapshot, addDoc, updateDoc, doc, 
  Timestamp, writeBatch, deleteDoc 
} from 'firebase/firestore';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

import { auth, db, signInWithGoogle, logOut, handleFirestoreError, OperationType } from './firebase';
import { Group, Expense, ActivityLog } from './types';
import { DebtSimplifier } from './components/DebtSimplifier';
import { SmartScanModal } from './components/SmartScanModal';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { MonetizationBanner } from './components/MonetizationBanner';
import { OfflineIndicator } from './components/OfflineIndicator';

const CURRENCIES = [
  { code: 'USD', symbol: '$' },
  { code: 'EUR', symbol: '€' },
  { code: 'GBP', symbol: '£' },
  { code: 'JPY', symbol: '¥' },
  { code: 'CAD', symbol: 'C$' },
  { code: 'AUD', symbol: 'A$' },
  { code: 'INR', symbol: '₹' },
  { code: 'SGD', symbol: 'S$' }
];

export default function App() {
  // Auth & Subscription
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isDemoUser, setIsDemoUser] = useState<boolean>(false);
  const [demoEmail, setDemoEmail] = useState<string>('guest.fintech@example.com');
  const [isPro, setIsPro] = useState<boolean>(false);
  const [scansCount, setScansCount] = useState<number>(0);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Groups & Workspace State
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // Modals & Dynamic UI Controllers
  const [isNewGroupOpen, setIsNewGroupOpen] = useState<boolean>(false);
  const [isNewExpenseOpen, setIsNewExpenseOpen] = useState<boolean>(false);
  const [isScanOpen, setIsScanOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'expenses' | 'simplify' | 'analytics' | 'activity'>('expenses');

  // Input States
  const [newGroupName, setNewGroupName] = useState<string>('');
  const [newGroupDesc, setNewGroupDesc] = useState<string>('');
  const [newGroupCurrency, setNewGroupCurrency] = useState<string>('USD');
  const [newGroupMembers, setNewGroupMembers] = useState<string>('');

  const [newExpenseTitle, setNewExpenseTitle] = useState<string>('');
  const [newExpenseAmount, setNewExpenseAmount] = useState<string>('');
  const [newExpensePaidBy, setNewExpensePaidBy] = useState<string>('');

  // Fallback storage state when Firestore has rules/quota issues
  const [isUsingLocalFallback, setIsUsingLocalFallback] = useState<boolean>(false);
  const [localGroups, setLocalGroups] = useState<Group[]>([]);
  const [localExpenses, setLocalExpenses] = useState<{ [groupId: string]: Expense[] }>({});
  const [localLogs, setLocalLogs] = useState<{ [groupId: string]: ActivityLog[] }>({});

  const currentUserEmail = user?.email || (isDemoUser ? demoEmail : '');
  const currentUserId = user?.uid || (isDemoUser ? 'demo-user-id' : '');

  // Compute user net balance for the selected group
  const userNetBalance = useMemo(() => {
    if (!selectedGroup || expenses.length === 0) return 0;
    
    const memberBalances: { [email: string]: number } = {};
    selectedGroup.members.forEach((email) => {
      memberBalances[email] = 0;
    });

    const activeExpenses = expenses.filter((e) => !e.deletedAt);

    activeExpenses.forEach((expense) => {
      const payer = expense.paidBy;
      const totalAmount = expense.totalAmount;

      if (!selectedGroup.members.includes(payer)) return;

      // Credit payer
      memberBalances[payer] += totalAmount;

      // Debit members
      if (expense.items && expense.items.length > 0) {
        const itemOwes: { [email: string]: number } = {};
        selectedGroup.members.forEach((m) => {
          itemOwes[m] = 0;
        });

        let totalAssignedCost = 0;
        expense.items.forEach((item) => {
          const assignees = item.assignedTo && item.assignedTo.length > 0
            ? item.assignedTo
            : selectedGroup.members;

          const share = item.price / assignees.length;
          assignees.forEach((email) => {
            if (selectedGroup.members.includes(email)) {
              itemOwes[email] += share;
              totalAssignedCost += share;
            }
          });
        });

        const remainingOverhead = totalAmount - totalAssignedCost;
        selectedGroup.members.forEach((email) => {
          let share = 0;
          if (totalAssignedCost > 0) {
            share = itemOwes[email] + (remainingOverhead * (itemOwes[email] / totalAssignedCost));
          } else {
            share = totalAmount / selectedGroup.members.length;
          }
          memberBalances[email] -= share;
        });
      } else {
        const share = totalAmount / selectedGroup.members.length;
        selectedGroup.members.forEach((email) => {
          memberBalances[email] -= share;
        });
      }
    });

    return memberBalances[currentUserEmail] || 0;
  }, [selectedGroup, expenses, currentUserEmail]);

  // Track subscription scans
  useEffect(() => {
    const savedScans = localStorage.getItem('splitwise_ocr_scans');
    if (savedScans) {
      setScansCount(parseInt(savedScans));
    }
  }, []);

  const incrementScanCount = () => {
    const newCount = scansCount + 1;
    setScansCount(newCount);
    localStorage.setItem('splitwise_ocr_scans', newCount.toString());
  };

  // Listen to Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        setIsDemoUser(false);
      } else {
        setUser(null);
      }
      setAuthLoading(false);
    });
    return unsubscribe;
  }, []);

  // Sync groups from Firebase or LocalStorage fallback
  useEffect(() => {
    if (!currentUserEmail) {
      setGroups([]);
      return;
    }

    if (isDemoUser || isUsingLocalFallback) {
      const saved = localStorage.getItem(`local_groups_${currentUserEmail}`);
      if (saved) {
        setGroups(JSON.parse(saved));
      } else {
        // Seed default sandbox demo group
        const defaultGroup: Group = {
          id: 'demo-sandbox-group',
          name: 'Cozy Apartment 301',
          description: 'Flatmate ledger for rent, utilities, and grocery runs.',
          members: [currentUserEmail, 'sarah.jones@example.com', 'mike.chen@example.com', 'john.doe@example.com'],
          createdAt: new Date().toISOString(),
          createdBy: currentUserId,
          currency: 'USD'
        };
        const list = [defaultGroup];
        localStorage.setItem(`local_groups_${currentUserEmail}`, JSON.stringify(list));
        setGroups(list);
      }
      return;
    }

    // Live Firebase Listener
    const path = 'groups';
    try {
      const q = query(collection(db, path), where('members', 'array-contains', currentUserEmail));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetched: Group[] = [];
        snapshot.forEach((docSnap) => {
          const d = docSnap.data();
          fetched.push({
            id: docSnap.id,
            name: d.name || '',
            description: d.description || '',
            members: d.members || [],
            createdAt: d.createdAt ? (d.createdAt.toDate ? d.createdAt.toDate() : d.createdAt) : '',
            createdBy: d.createdBy || '',
            currency: d.currency || 'USD'
          });
        });
        setGroups(fetched);
      }, (err) => {
        console.warn("Firestore access denied. Activating offline fallback database.", err);
        setIsUsingLocalFallback(true);
      });
      return unsubscribe;
    } catch (e) {
      console.error(e);
      setIsUsingLocalFallback(true);
    }
  }, [currentUserEmail, isDemoUser, isUsingLocalFallback]);

  // Sync expenses & logs for the selected group
  useEffect(() => {
    if (!selectedGroup) {
      setExpenses([]);
      setActivityLogs([]);
      return;
    }

    if (isDemoUser || isUsingLocalFallback) {
      const savedExp = localStorage.getItem(`local_expenses_${selectedGroup.id}`);
      const savedLogs = localStorage.getItem(`local_logs_${selectedGroup.id}`);
      
      if (savedExp) {
        setExpenses(JSON.parse(savedExp));
      } else {
        // Seed initial expenses
        const initialExpenses: Expense[] = [
          {
            id: 'exp-1',
            groupId: selectedGroup.id,
            title: 'Weekly Groceries Scan',
            paidBy: 'sarah.jones@example.com',
            totalAmount: 90.00,
            subtotal: 83.50,
            tax: 6.50,
            items: [
              { id: '1', name: 'Fresh Vegetables', price: 15.00, assignedTo: ['sarah.jones@example.com', currentUserEmail] },
              { id: '2', name: 'Organic Milk & Cheese', price: 24.50, assignedTo: ['mike.chen@example.com', 'john.doe@example.com'] },
              { id: '3', name: 'Wagyu Burgers', price: 44.00, assignedTo: ['mike.chen@example.com', 'john.doe@example.com', currentUserEmail] }
            ],
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            deletedAt: null
          },
          {
            id: 'exp-2',
            groupId: selectedGroup.id,
            title: 'House Broadband Internet',
            paidBy: currentUserEmail,
            totalAmount: 60.00,
            subtotal: 60.00,
            tax: 0,
            items: [],
            createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
            updatedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
            deletedAt: null
          }
        ];
        localStorage.setItem(`local_expenses_${selectedGroup.id}`, JSON.stringify(initialExpenses));
        setExpenses(initialExpenses);
      }

      if (savedLogs) {
        setActivityLogs(JSON.parse(savedLogs));
      } else {
        const initialLogs: ActivityLog[] = [
          {
            id: 'log-1',
            groupId: selectedGroup.id,
            userId: 'sarah-uid',
            userName: 'Sarah Jones',
            action: 'CREATED_EXPENSE',
            details: 'Added Weekly Groceries ($90.00)',
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            id: 'log-2',
            groupId: selectedGroup.id,
            userId: currentUserId,
            userName: 'You',
            action: 'CREATED_GROUP',
            details: 'Initialized ledger workspace Cozy Apartment 301',
            createdAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString()
          }
        ];
        localStorage.setItem(`local_logs_${selectedGroup.id}`, JSON.stringify(initialLogs));
        setActivityLogs(initialLogs);
      }
      return;
    }

    // Live Firebase Listener for Expenses
    const expPath = `groups/${selectedGroup.id}/expenses`;
    const logsPath = `groups/${selectedGroup.id}/activity_logs`;

    let unsubscribeExp = () => {};
    let unsubscribeLogs = () => {};

    try {
      unsubscribeExp = onSnapshot(collection(db, expPath), (snapshot) => {
        const fetched: Expense[] = [];
        snapshot.forEach((docSnap) => {
          const d = docSnap.data();
          fetched.push({
            id: docSnap.id,
            groupId: selectedGroup.id,
            title: d.title || '',
            paidBy: d.paidBy || '',
            totalAmount: Number(d.totalAmount) || 0,
            subtotal: Number(d.subtotal) || 0,
            tax: Number(d.tax) || 0,
            items: d.items || [],
            createdAt: d.createdAt ? (d.createdAt.toDate ? d.createdAt.toDate() : d.createdAt) : '',
            updatedAt: d.updatedAt ? (d.updatedAt.toDate ? d.updatedAt.toDate() : d.updatedAt) : '',
            deletedAt: d.deletedAt || null
          });
        });
        setExpenses(fetched.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, expPath);
      });

      unsubscribeLogs = onSnapshot(collection(db, logsPath), (snapshot) => {
        const fetched: ActivityLog[] = [];
        snapshot.forEach((docSnap) => {
          const d = docSnap.data();
          fetched.push({
            id: docSnap.id,
            groupId: selectedGroup.id,
            userId: d.userId || '',
            userName: d.userName || '',
            action: d.action || '',
            details: d.details || '',
            createdAt: d.createdAt ? (d.createdAt.toDate ? d.createdAt.toDate() : d.createdAt) : ''
          });
        });
        setActivityLogs(fetched.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, logsPath);
      });

    } catch (error) {
      console.error(error);
    }

    return () => {
      unsubscribeExp();
      unsubscribeLogs();
    };
  }, [selectedGroup, isDemoUser, isUsingLocalFallback]);

  const activeCurrencySymbol = () => {
    if (!selectedGroup) return '$';
    return CURRENCIES.find((c) => c.code === selectedGroup.currency)?.symbol || '$';
  };

  // Group creation
  const handleCreateGroup = async () => {
    if (!newGroupName.trim()) return;

    const emails = newGroupMembers
      .split(',')
      .map((e) => e.trim().toLowerCase())
      .filter((e) => e !== '');
    
    // Auto-include current user in group
    if (!emails.includes(currentUserEmail)) {
      emails.unshift(currentUserEmail);
    }

    const groupPayload: Omit<Group, 'id'> = {
      name: newGroupName.trim(),
      description: newGroupDesc.trim(),
      members: emails,
      createdAt: new Date().toISOString(),
      createdBy: currentUserId,
      currency: newGroupCurrency
    };

    if (isDemoUser || isUsingLocalFallback) {
      const newGroup: Group = { ...groupPayload, id: 'g-' + Date.now() };
      const updated = [newGroup, ...groups];
      localStorage.setItem(`local_groups_${currentUserEmail}`, JSON.stringify(updated));
      setGroups(updated);
      setSelectedGroup(newGroup);
    } else {
      const path = 'groups';
      try {
        const docRef = await addDoc(collection(db, path), groupPayload);
        await updateDoc(docRef, { id: docRef.id });
        setSelectedGroup({ ...groupPayload, id: docRef.id });
      } catch (err) {
        console.warn("Firestore error creating group, falling back.", err);
        setIsUsingLocalFallback(true);
      }
    }

    // Reset fields
    setNewGroupName('');
    setNewGroupDesc('');
    setNewGroupCurrency('USD');
    setNewGroupMembers('');
    setIsNewGroupOpen(false);
  };

  // Manual Expense creation
  const handleCreateExpense = async () => {
    if (!newExpenseTitle.trim() || !newExpenseAmount) return;

    const amount = parseFloat(newExpenseAmount) || 0;
    const paidBy = newExpensePaidBy || currentUserEmail;

    const expensePayload: Omit<Expense, 'id'> = {
      groupId: selectedGroup!.id,
      title: newExpenseTitle.trim(),
      paidBy,
      totalAmount: amount,
      subtotal: amount,
      tax: 0,
      items: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deletedAt: null
    };

    const logPayload: Omit<ActivityLog, 'id'> = {
      groupId: selectedGroup!.id,
      userId: currentUserId,
      userName: isDemoUser ? 'Demo Guest' : (user?.displayName || currentUserEmail.split('@')[0]),
      action: 'CREATED_EXPENSE',
      details: `Added "${newExpenseTitle}" (${activeCurrencySymbol()}${amount.toFixed(2)}) paid by ${paidBy.split('@')[0]}`,
      createdAt: new Date().toISOString()
    };

    if (isDemoUser || isUsingLocalFallback) {
      const expenseId = 'e-' + Date.now();
      const newExpense: Expense = { ...expensePayload, id: expenseId };
      const updatedExpenses = [newExpense, ...expenses];
      localStorage.setItem(`local_expenses_${selectedGroup!.id}`, JSON.stringify(updatedExpenses));
      setExpenses(updatedExpenses);

      const logId = 'l-' + Date.now();
      const newLog: ActivityLog = { ...logPayload, id: logId };
      const updatedLogs = [newLog, ...activityLogs];
      localStorage.setItem(`local_logs_${selectedGroup!.id}`, JSON.stringify(updatedLogs));
      setActivityLogs(updatedLogs);
    } else {
      try {
        const expRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/expenses`), expensePayload);
        await updateDoc(expRef, { id: expRef.id });

        const logRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/activity_logs`), logPayload);
        await updateDoc(logRef, { id: logRef.id });
      } catch (err) {
        console.error("Firestore error creating expense.", err);
      }
    }

    // Reset inputs
    setNewExpenseTitle('');
    setNewExpenseAmount('');
    setNewExpensePaidBy('');
    setIsNewExpenseOpen(false);
  };

  // Settle transaction
  const handleSettleUp = async (debtor: string, creditor: string, amount: number) => {
    const title = `Settle Up: ${debtor.split('@')[0]} to ${creditor.split('@')[0]}`;
    const expensePayload: Omit<Expense, 'id'> = {
      groupId: selectedGroup!.id,
      title,
      paidBy: debtor,
      totalAmount: amount,
      subtotal: amount,
      tax: 0,
      items: [
        { id: '1', name: `Settlement payout to ${creditor.split('@')[0]}`, price: amount, assignedTo: [creditor] }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deletedAt: null
    };

    const logPayload: Omit<ActivityLog, 'id'> = {
      groupId: selectedGroup!.id,
      userId: currentUserId,
      userName: isDemoUser ? 'Demo Guest' : (user?.displayName || currentUserEmail.split('@')[0]),
      action: 'SETTLED_DEBT',
      details: `${debtor.split('@')[0]} settled debt of ${activeCurrencySymbol()}${amount.toFixed(2)} with ${creditor.split('@')[0]}`,
      createdAt: new Date().toISOString()
    };

    if (isDemoUser || isUsingLocalFallback) {
      const expenseId = 'e-' + Date.now();
      const newExpense: Expense = { ...expensePayload, id: expenseId };
      const updatedExpenses = [newExpense, ...expenses];
      localStorage.setItem(`local_expenses_${selectedGroup!.id}`, JSON.stringify(updatedExpenses));
      setExpenses(updatedExpenses);

      const logId = 'l-' + Date.now();
      const newLog: ActivityLog = { ...logPayload, id: logId };
      const updatedLogs = [newLog, ...activityLogs];
      localStorage.setItem(`local_logs_${selectedGroup!.id}`, JSON.stringify(updatedLogs));
      setActivityLogs(updatedLogs);
    } else {
      try {
        const expRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/expenses`), expensePayload);
        await updateDoc(expRef, { id: expRef.id });

        const logRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/activity_logs`), logPayload);
        await updateDoc(logRef, { id: logRef.id });
      } catch (err) {
        console.error("Firestore error settling.", err);
      }
    }
  };

  // Smart receipt scan complete
  const handleSmartScanConfirm = async (scannedData: {
    title: string;
    items: { name: string; price: number; quantity: number }[];
    subtotal: number;
    tax: number;
    totalAmount: number;
  }) => {
    // Increment scans usage
    incrementScanCount();

    // Map scanned items to standard ReceiptItems
    const mappedItems = scannedData.items.map((it, idx) => ({
      id: String(idx + 1),
      name: it.name,
      price: it.price,
      assignedTo: [] // Blank initially for members to claim
    }));

    const expensePayload: Omit<Expense, 'id'> = {
      groupId: selectedGroup!.id,
      title: scannedData.title,
      paidBy: currentUserEmail,
      totalAmount: scannedData.totalAmount,
      subtotal: scannedData.subtotal,
      tax: scannedData.tax,
      items: mappedItems,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      deletedAt: null
    };

    const logPayload: Omit<ActivityLog, 'id'> = {
      groupId: selectedGroup!.id,
      userId: currentUserId,
      userName: isDemoUser ? 'Demo Guest' : (user?.displayName || currentUserEmail.split('@')[0]),
      action: 'SMART_SCAN_EXPENSE',
      details: `Scanned & parsed receipt "${scannedData.title}" (${activeCurrencySymbol()}${scannedData.totalAmount.toFixed(2)}) using Gemini`,
      createdAt: new Date().toISOString()
    };

    if (isDemoUser || isUsingLocalFallback) {
      const expenseId = 'e-' + Date.now();
      const newExpense: Expense = { ...expensePayload, id: expenseId };
      const updatedExpenses = [newExpense, ...expenses];
      localStorage.setItem(`local_expenses_${selectedGroup!.id}`, JSON.stringify(updatedExpenses));
      setExpenses(updatedExpenses);

      const logId = 'l-' + Date.now();
      const newLog: ActivityLog = { ...logPayload, id: logId };
      const updatedLogs = [newLog, ...activityLogs];
      localStorage.setItem(`local_logs_${selectedGroup!.id}`, JSON.stringify(updatedLogs));
      setActivityLogs(updatedLogs);
    } else {
      try {
        const expRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/expenses`), expensePayload);
        await updateDoc(expRef, { id: expRef.id });

        const logRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/activity_logs`), logPayload);
        await updateDoc(logRef, { id: logRef.id });
      } catch (err) {
        console.error("Firestore error importing scanned bill.", err);
      }
    }
  };

  // Toggle item assignee
  const handleToggleItemAssignee = async (expense: Expense, itemId: string, email: string) => {
    const updatedItems = expense.items.map((item) => {
      if (item.id === itemId) {
        const exists = item.assignedTo.includes(email);
        const nextAssignees = exists
          ? item.assignedTo.filter((e) => e !== email)
          : [...item.assignedTo, email];
        return { ...item, assignedTo: nextAssignees };
      }
      return item;
    });

    if (isDemoUser || isUsingLocalFallback) {
      const updatedExpenses = expenses.map((e) => {
        if (e.id === expense.id) {
          return { ...e, items: updatedItems, updatedAt: new Date().toISOString() };
        }
        return e;
      });
      localStorage.setItem(`local_expenses_${selectedGroup!.id}`, JSON.stringify(updatedExpenses));
      setExpenses(updatedExpenses);
    } else {
      try {
        const expDoc = doc(db, `groups/${selectedGroup!.id}/expenses`, expense.id);
        await updateDoc(expDoc, {
          items: updatedItems,
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Soft delete expense
  const handleSoftDeleteExpense = async (expense: Expense) => {
    const timestamp = new Date().toISOString();

    const logPayload: Omit<ActivityLog, 'id'> = {
      groupId: selectedGroup!.id,
      userId: currentUserId,
      userName: isDemoUser ? 'Demo Guest' : (user?.displayName || currentUserEmail.split('@')[0]),
      action: 'DELETED_EXPENSE',
      details: `Soft deleted expense "${expense.title}" (${activeCurrencySymbol()}${expense.totalAmount.toFixed(2)})`,
      createdAt: timestamp
    };

    if (isDemoUser || isUsingLocalFallback) {
      const updatedExpenses = expenses.map((e) => {
        if (e.id === expense.id) {
          return { ...e, deletedAt: timestamp };
        }
        return e;
      });
      localStorage.setItem(`local_expenses_${selectedGroup!.id}`, JSON.stringify(updatedExpenses));
      setExpenses(updatedExpenses);

      const logId = 'l-' + Date.now();
      const newLog: ActivityLog = { ...logPayload, id: logId };
      const updatedLogs = [newLog, ...activityLogs];
      localStorage.setItem(`local_logs_${selectedGroup!.id}`, JSON.stringify(updatedLogs));
      setActivityLogs(updatedLogs);
    } else {
      try {
        const expDoc = doc(db, `groups/${selectedGroup!.id}/expenses`, expense.id);
        await updateDoc(expDoc, { deletedAt: timestamp });

        const logRef = await addDoc(collection(db, `groups/${selectedGroup!.id}/activity_logs`), logPayload);
        await updateDoc(logRef, { id: logRef.id });
      } catch (err) {
        console.error(err);
      }
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center">
        <RefreshCcw className="h-8 w-8 text-emerald-600 animate-spin" />
        <span className="text-xs font-semibold text-gray-500 mt-2.5">Syncing secure connection...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans flex flex-col antialiased selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* Floating Offline Status */}
      <OfflineIndicator />

      {/* Landing / Welcome Sign-In flow */}
      {!currentUserEmail ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 bg-gradient-to-tr from-gray-50 via-slate-50 to-emerald-50/20 relative">
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-emerald-100/30 rounded-full filter blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-teal-100/20 rounded-full filter blur-3xl" />

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md text-center bg-white border border-gray-100 p-8 rounded-3xl shadow-xl shadow-gray-200/50 relative z-10"
          >
            <div className="h-14 w-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-lg shadow-emerald-600/10 mx-auto mb-6">
              <Sparkles className="h-7 w-7" />
            </div>

            <h1 className="text-2xl font-black text-gray-900 tracking-tight">SplitWise 2.0</h1>
            <span className="text-xs font-bold text-emerald-600 tracking-widest uppercase block mt-1.5 mb-3">
              The Intelligent Fintech Ledger
            </span>
            <p className="text-sm text-gray-500 leading-relaxed max-w-sm mx-auto mb-8">
              A high-precision multi-currency expense ledger featuring smart camera receipt scanning, transaction simplification flow maps, and group analytics.
            </p>

            <div className="space-y-4">
              <button
                onClick={signInWithGoogle}
                className="w-full py-3 bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <img 
                  src="https://www.gstatic.com/mobilesdk/160503_mobilesdk/images/favicon.ico" 
                  alt="Google" 
                  className="w-4 h-4"
                />
                Continue with Google Sign-In
              </button>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-gray-100" />
                <span className="flex-shrink mx-4 text-[10px] text-gray-400 font-extrabold uppercase tracking-widest">
                  or try demo sandbox
                </span>
                <div className="flex-grow border-t border-gray-100" />
              </div>

              <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3 text-left">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
                    Developer Guest Mode
                  </span>
                  <span className="text-[9px] bg-emerald-500 text-white font-black px-1 rounded-sm">FREE ACCESS</span>
                </div>
                <input
                  type="email"
                  value={demoEmail}
                  onChange={(e) => setDemoEmail(e.target.value)}
                  placeholder="enter email"
                  className="w-full px-3 py-1.5 text-xs bg-white border border-gray-200 rounded-lg focus:outline-hidden text-gray-700 font-semibold mb-2.5"
                />
                <button
                  onClick={() => setIsDemoUser(true)}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Play className="h-3.5 w-3.5" /> Launch Interactive Sandbox
                </button>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-50 flex items-center justify-center gap-1.5 text-[10px] text-gray-400 font-semibold">
              <ClipboardList className="h-3.5 w-3.5 text-gray-400" />
              <span>Conforms to Cloud Security Architecture & ABAC Rules</span>
            </div>
          </motion.div>
        </div>
      ) : (
        /* Authenticated Application Workspace */
        <div className="flex-1 flex flex-col">
          {/* Main Top Header */}
          <header className="bg-white border-b border-slate-200 flex items-center justify-between px-6 py-4 sticky top-0 z-30 shrink-0">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSelectedGroup(null)}
                className={`p-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors cursor-pointer ${
                  !selectedGroup ? 'hidden' : ''
                }`}
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-none flex items-center justify-center rotate-45 select-none transition-transform hover:rotate-135 duration-300">
                  <div className="-rotate-45 text-white font-extrabold text-lg">S</div>
                </div>
                <div>
                  <h1 className="text-xl font-bold tracking-tight uppercase text-slate-900">SplitWise 2.0</h1>
                  <span className="text-[10px] font-bold text-blue-600 tracking-wider uppercase block -mt-1">
                    {selectedGroup ? selectedGroup.name : 'Ledger Dashboard'}
                  </span>
                </div>
              </div>
            </div>

            {/* Top Navigation Balance and Credentials */}
            <div className="flex items-center gap-8">
              {selectedGroup && (
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Personal Net Balance</p>
                  <p className={`text-xl font-mono font-bold ${userNetBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {userNetBalance >= 0 ? '+' : ''}{activeCurrencySymbol()}{userNetBalance.toFixed(2)}
                  </p>
                </div>
              )}

              <div className="flex items-center gap-3 border-l border-slate-200 pl-6 h-10">
                <div className="text-right">
                  <span className="text-xs font-bold text-slate-900 block">{currentUserEmail.split('@')[0]}</span>
                  <span className="text-[10px] text-slate-400 font-mono block tracking-wider uppercase">{isDemoUser ? 'SANDBOX' : 'SECURE AUTH'}</span>
                </div>
                <button
                  onClick={() => {
                    if (isDemoUser) {
                      setIsDemoUser(false);
                    } else {
                      logOut();
                    }
                    setSelectedGroup(null);
                  }}
                  className="p-2 bg-slate-50 hover:bg-rose-50 hover:text-rose-600 text-slate-500 transition-colors cursor-pointer"
                  title="Log Out"
                >
                  <LogOut className="h-4.5 w-4.5" />
                </button>
              </div>
            </div>
          </header>

          <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
            
            {/* Top subscription promo info */}
            <MonetizationBanner 
              isPro={isPro} 
              onTogglePro={() => setIsPro(!isPro)} 
              scansCount={scansCount} 
            />

            {/* View switcher: Group select vs. Group detail workspace */}
            {!selectedGroup ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                      <Layers className="h-5 w-5 text-emerald-500" />
                      Collaborative Ledgers
                    </h2>
                    <p className="text-xs text-gray-500">Select a collaborative group ledger to review splits and simplifications.</p>
                  </div>
                  <button
                    onClick={() => setIsNewGroupOpen(true)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer animate-pulse"
                  >
                    <Plus className="h-4 w-4" /> Create Group
                  </button>
                </div>

                {/* Groups Grid */}
                {groups.length === 0 ? (
                  <div className="text-center py-16 bg-white border border-gray-100 rounded-3xl shadow-xs">
                    <Users className="mx-auto h-12 w-12 text-gray-300 mb-3" />
                    <h3 className="text-sm font-bold text-gray-900">No ledgers initialized</h3>
                    <p className="text-xs text-gray-500 max-w-sm mx-auto mt-1 mb-5">Create a group ledger and invite friends using their emails to split grocery runs, apartments, and outings.</p>
                    <button
                      onClick={() => setIsNewGroupOpen(true)}
                      className="px-4 py-2 bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
                    >
                      Initialize first Group
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {groups.map((group) => {
                      const sym = CURRENCIES.find((c) => c.code === group.currency)?.symbol || '$';
                      return (
                        <motion.div
                          key={group.id}
                          whileHover={{ y: -4, border: '1px solid #10B981' }}
                          onClick={() => {
                            setSelectedGroup(group);
                            setActiveTab('expenses');
                          }}
                          className="bg-white border border-gray-100 rounded-3xl p-5 shadow-xs cursor-pointer transition-all flex flex-col justify-between h-[160px] relative group"
                        >
                          <div>
                            <div className="flex justify-between items-start">
                              <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-0.5 rounded border border-gray-100">
                                {group.currency} ({sym})
                              </span>
                              <span className="text-xs text-gray-400 flex items-center gap-1">
                                <Users className="h-3.5 w-3.5" /> {group.members.length} members
                              </span>
                            </div>
                            <h3 className="text-base font-bold text-gray-900 mt-2.5 truncate group-hover:text-emerald-700 transition-colors">
                              {group.name}
                            </h3>
                            <p className="text-xs text-gray-500 line-clamp-2 mt-1">
                              {group.description || 'No ledger description provided.'}
                            </p>
                          </div>
                          
                          <div className="border-t border-gray-50 pt-3 flex items-center justify-between text-[10px] text-gray-400 font-medium">
                            <span>Created {new Date(group.createdAt).toLocaleDateString()}</span>
                            <span className="text-emerald-600 font-bold group-hover:underline flex items-center gap-0.5">
                              Open Workspace <ArrowLeft className="h-3 w-3 rotate-180" />
                            </span>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              /* Group Ledger Active Workspace */
              <div className="space-y-6">
                {/* Workspace Header Panel */}
                <div className="bg-white border border-gray-100 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase">
                        Active Workspace
                      </span>
                      <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
                        {selectedGroup.currency} ({activeCurrencySymbol()})
                      </span>
                    </div>
                    <h2 className="text-xl font-black text-gray-950 mt-1.5">{selectedGroup.name}</h2>
                    <p className="text-xs text-gray-500 mt-0.5">{selectedGroup.description}</p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <button
                      onClick={() => setIsScanOpen(true)}
                      className="px-4.5 py-2.5 bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer relative group overflow-hidden"
                    >
                      <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform" />
                      <Sparkles className="h-4 w-4 text-amber-300 animate-pulse" />
                      <span>Smart Scan Receipt</span>
                    </button>

                    <button
                      onClick={() => setIsNewExpenseOpen(true)}
                      className="px-4.5 py-2.5 bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Add Expense Manually</span>
                    </button>
                  </div>
                </div>

                {/* Tab Navigation */}
                <div className="border-b border-gray-200 flex flex-wrap gap-1">
                  <button
                    onClick={() => setActiveTab('expenses')}
                    className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                      activeTab === 'expenses'
                        ? 'border-emerald-600 text-emerald-700 font-extrabold'
                        : 'border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    Group Ledger ({expenses.filter((e) => !e.deletedAt).length})
                  </button>
                  <button
                    onClick={() => setActiveTab('simplify')}
                    className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                      activeTab === 'simplify'
                        ? 'border-emerald-600 text-emerald-700 font-extrabold'
                        : 'border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    Debt Simplifier Flow Map
                  </button>
                  <button
                    onClick={() => setActiveTab('analytics')}
                    className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                      activeTab === 'analytics'
                        ? 'border-emerald-600 text-emerald-700 font-extrabold'
                        : 'border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    Glutton Analytics Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab('activity')}
                    className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                      activeTab === 'activity'
                        ? 'border-emerald-600 text-emerald-700 font-extrabold'
                        : 'border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    Audit Activity Logs ({activityLogs.length})
                  </button>
                </div>

                {/* Tab Contents */}
                <div className="space-y-6">
                  
                  {/* Ledger Tab */}
                  {activeTab === 'expenses' && (
                    <div className="space-y-6">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                        <div>
                          <h3 className="text-base font-bold text-gray-900">Receipts & Expenses</h3>
                          <p className="text-xs text-gray-500">Interactive items assignment. Claims on line items directly update balances.</p>
                        </div>
                        {isUsingLocalFallback && (
                          <div className="px-3 py-1.5 bg-amber-50 text-amber-800 text-[10px] font-mono font-bold rounded-lg border border-amber-200">
                            OFFLINE BACKUP DB ACTIVE
                          </div>
                        )}
                      </div>

                      {expenses.filter((e) => !e.deletedAt).length === 0 ? (
                        <div className="text-center py-16 bg-white border border-gray-100 rounded-3xl shadow-xs">
                          <ClipboardList className="mx-auto h-12 w-12 text-gray-300 mb-3" />
                          <h3 className="text-sm font-bold text-gray-900">No expenses recorded</h3>
                          <p className="text-xs text-gray-500 max-w-xs mx-auto mt-1 mb-5">
                            Trigger the smart scanner or enter an expense manually to start splitting with your group.
                          </p>
                          <div className="flex gap-3 justify-center">
                            <button
                              onClick={() => setIsScanOpen(true)}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer"
                            >
                              Smart Scan
                            </button>
                            <button
                              onClick={() => setIsNewExpenseOpen(true)}
                              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold text-xs rounded-xl cursor-pointer"
                            >
                              Manual Entry
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 gap-6">
                          {expenses
                            .filter((e) => !e.deletedAt)
                            .map((expense) => (
                              <motion.div
                                key={expense.id}
                                layout
                                className="bg-white border border-gray-100 rounded-3xl p-5 shadow-xs hover:shadow-md/5 transition-all"
                              >
                                <div className="flex items-start justify-between gap-4 border-b border-gray-50 pb-4">
                                  <div>
                                    <h4 className="text-base font-bold text-gray-900">{expense.title}</h4>
                                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-500 mt-1">
                                      <span className="flex items-center gap-1 font-medium">
                                        <User className="h-3.5 w-3.5 text-emerald-600" />
                                        Paid by: <strong className="text-gray-800 font-bold">{expense.paidBy.split('@')[0]}</strong>
                                      </span>
                                      <span>•</span>
                                      <span className="flex items-center gap-1">
                                        <Calendar className="h-3.5 w-3.5 text-gray-400" />
                                        {new Date(expense.createdAt).toLocaleDateString()}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="flex items-center gap-3">
                                    <div className="text-right">
                                      <span className="text-[10px] font-bold text-gray-400 block uppercase tracking-wider">Amount</span>
                                      <span className="text-lg font-extrabold text-gray-900">
                                        {activeCurrencySymbol()}
                                        {expense.totalAmount.toFixed(2)}
                                      </span>
                                    </div>
                                    <button
                                      onClick={() => handleSoftDeleteExpense(expense)}
                                      className="p-1.5 rounded-lg text-gray-400 hover:text-rose-500 hover:bg-rose-50 transition-all cursor-pointer"
                                      title="Delete Expense"
                                    >
                                      <Trash2 className="h-4.5 w-4.5" />
                                    </button>
                                  </div>
                                </div>

                                {/* Item Assignments / Claim breakdown */}
                                {expense.items && expense.items.length > 0 ? (
                                  <div className="mt-4 space-y-3.5">
                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">
                                      Receipt Items Claim Grid (Tap name to toggle assignment)
                                    </span>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                      {expense.items.map((item) => (
                                        <div
                                          key={item.id}
                                          className="p-3 bg-gray-50/50 rounded-2xl border border-gray-100 flex flex-col justify-between"
                                        >
                                          <div className="flex justify-between items-start gap-2 mb-2.5">
                                            <span className="text-xs font-bold text-gray-800 truncate">{item.name}</span>
                                            <span className="text-xs font-black text-emerald-700 shrink-0 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                                              {activeCurrencySymbol()}{item.price.toFixed(2)}
                                            </span>
                                          </div>

                                          <div className="flex flex-wrap gap-1.5">
                                            {selectedGroup.members.map((email) => {
                                              const isAssigned = item.assignedTo.includes(email);
                                              return (
                                                <button
                                                  key={email}
                                                  onClick={() => handleToggleItemAssignee(expense, item.id, email)}
                                                  className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                                                    isAssigned
                                                      ? 'bg-emerald-600 text-white border-emerald-600'
                                                      : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-100'
                                                  }`}
                                                >
                                                  {isAssigned && <Check className="h-2.5 w-2.5" />}
                                                  <span>{email.split('@')[0]}</span>
                                                </button>
                                              );
                                            })}
                                          </div>
                                        </div>
                                      ))}
                                    </div>

                                    {/* Tax & Subtotal details */}
                                    {(expense.tax > 0 || expense.subtotal > 0) && (
                                      <div className="mt-4 pt-3 border-t border-gray-50 flex justify-end gap-5 text-[10px] text-gray-500 font-semibold">
                                        {expense.subtotal > 0 && (
                                          <span>Subtotal: {activeCurrencySymbol()}{expense.subtotal.toFixed(2)}</span>
                                        )}
                                        {expense.tax > 0 && (
                                          <span>Tax & overhead (split equally): {activeCurrencySymbol()}{expense.tax.toFixed(2)}</span>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                ) : (
                                  <div className="mt-4 flex items-center justify-between p-3 bg-blue-50/30 rounded-2xl border border-blue-100/50">
                                    <span className="text-xs text-blue-800 font-medium">
                                      Split equally among all {selectedGroup.members.length} group members.
                                    </span>
                                    <span className="text-xs font-bold text-blue-900 font-mono">
                                      {activeCurrencySymbol()}
                                      {(expense.totalAmount / selectedGroup.members.length).toFixed(2)} / member
                                    </span>
                                  </div>
                                )}
                              </motion.div>
                            ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Debt Simplifier Tab */}
                  {activeTab === 'simplify' && (
                    <DebtSimplifier
                      group={selectedGroup}
                      expenses={expenses}
                      currencySymbol={activeCurrencySymbol()}
                      onSettle={handleSettleUp}
                    />
                  )}

                  {/* Analytics Dashboard Tab */}
                  {activeTab === 'analytics' && (
                    <AnalyticsDashboard
                      group={selectedGroup}
                      expenses={expenses}
                      currencySymbol={activeCurrencySymbol()}
                    />
                  )}

                  {/* Activity Log Tab */}
                  {activeTab === 'activity' && (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                          <ClipboardList className="h-5 w-5 text-emerald-500" />
                          Relational Audit Trail
                        </h3>
                        <p className="text-xs text-gray-500">Immutable activities feed tracking updates, deleted line items, and smart scans.</p>
                      </div>

                      <div className="bg-white border border-gray-100 rounded-3xl p-6 shadow-xs divide-y divide-gray-50">
                        {activityLogs.length === 0 ? (
                          <p className="text-xs text-gray-400 font-mono py-4">No audit activity logged</p>
                        ) : (
                          activityLogs.map((log) => (
                            <div key={log.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 first:pt-0 last:pb-0">
                              <div className="flex items-start gap-3">
                                <div className="h-6 w-6 rounded bg-gray-100 flex items-center justify-center text-[10px] font-bold text-gray-600 shrink-0 mt-0.5">
                                  {log.action.substring(0, 2)}
                                </div>
                                <div>
                                  <span className="text-xs font-bold text-gray-900 block">{log.details}</span>
                                  <span className="text-[10px] text-gray-400 mt-0.5 block">
                                    Triggered by: {log.userName} ({log.userId === currentUserId ? 'You' : 'Member'})
                                  </span>
                                </div>
                              </div>
                              <span className="text-[10px] font-mono text-gray-400 shrink-0">
                                {new Date(log.createdAt).toLocaleString()}
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                </div>
              </div>
            )}

          </main>
        </div>
      )}

      {/* MODALS SECTION */}

      {/* New Group Drawer/Modal */}
      <AnimatePresence>
        {isNewGroupOpen && (
          <div className="fixed inset-0 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 shadow-xl w-full max-w-md overflow-hidden relative"
            >
              <button
                onClick={() => setIsNewGroupOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-gray-100 text-gray-400 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>

              <h3 className="text-lg font-bold text-gray-900 mb-1.5 flex items-center gap-1.5">
                <Users className="h-5 w-5 text-emerald-600" />
                Initialize Group Ledger
              </h3>
              <p className="text-xs text-gray-500 mb-5">Create a separate ledger space with unique currencies and guest member rosters.</p>

              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Group Title</label>
                  <input
                    type="text"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    placeholder="e.g. Apartment 301 Utilities, Eurotrip 2026"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Description</label>
                  <input
                    type="text"
                    value={newGroupDesc}
                    onChange={(e) => setNewGroupDesc(e.target.value)}
                    placeholder="Brief description of ledger purpose"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-medium"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Currency</label>
                    <select
                      value={newGroupCurrency}
                      onChange={(e) => setNewGroupCurrency(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-bold"
                    >
                      {CURRENCIES.map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.code} ({c.symbol})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Host User</label>
                    <input
                      type="text"
                      disabled
                      value={currentUserEmail.split('@')[0]}
                      className="w-full px-4 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-xs font-bold text-gray-500 cursor-not-allowed"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Member Roster Emails</label>
                    <span className="text-[9px] text-emerald-600 font-semibold flex items-center gap-1">
                      <UserPlus className="h-3 w-3" /> Comma-separated list
                    </span>
                  </div>
                  <input
                    type="text"
                    value={newGroupMembers}
                    onChange={(e) => setNewGroupMembers(e.target.value)}
                    placeholder="e.g. sarah@example.com, mike@example.com"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-medium"
                  />
                </div>

                <button
                  onClick={handleCreateGroup}
                  disabled={!newGroupName.trim()}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-100 disabled:text-gray-400 text-white font-bold text-xs rounded-xl shadow-md transition-colors mt-4 cursor-pointer"
                >
                  Create Group Ledger Workspace
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Manual Expense Modal */}
      <AnimatePresence>
        {isNewExpenseOpen && selectedGroup && (
          <div className="fixed inset-0 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 shadow-xl w-full max-w-md overflow-hidden relative"
            >
              <button
                onClick={() => setIsNewExpenseOpen(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-gray-100 text-gray-400 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>

              <h3 className="text-lg font-bold text-gray-900 mb-1.5 flex items-center gap-1.5">
                <DollarSign className="h-5 w-5 text-emerald-600" />
                Add Expense Record
              </h3>
              <p className="text-xs text-gray-500 mb-5">Manually record a simple shared group expense. Splits equally among all roster members.</p>

              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Expense Title</label>
                  <input
                    type="text"
                    value={newExpenseTitle}
                    onChange={(e) => setNewExpenseTitle(e.target.value)}
                    placeholder="e.g. Electric bill, Uber trip home"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-semibold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      Amount ({selectedGroup.currency})
                    </label>
                    <div className="relative">
                      <span className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-xs font-bold text-gray-400">
                        {activeCurrencySymbol()}
                      </span>
                      <input
                        type="number"
                        step="0.01"
                        value={newExpenseAmount}
                        onChange={(e) => setNewExpenseAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full pl-8 pr-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Who paid?</label>
                    <select
                      value={newExpensePaidBy}
                      onChange={(e) => setNewExpensePaidBy(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 focus:border-emerald-500 focus:bg-white rounded-xl focus:outline-hidden text-sm font-bold"
                    >
                      {selectedGroup.members.map((email) => (
                        <option key={email} value={email}>
                          {email === currentUserEmail ? 'You' : email.split('@')[0]}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleCreateExpense}
                  disabled={!newExpenseTitle.trim() || !newExpenseAmount}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-100 disabled:text-gray-400 text-white font-bold text-xs rounded-xl shadow-md transition-colors mt-4 cursor-pointer"
                >
                  Confirm Group Expense
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Smart Scan Receipt Modal */}
      <SmartScanModal
        isOpen={isScanOpen}
        onClose={() => setIsScanOpen(false)}
        onConfirm={handleSmartScanConfirm}
        isPro={isPro}
      />

      {/* Sticky Audit Trail Footer */}
      {currentUserEmail && (
        <footer className="h-12 bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between px-8 text-[9px] uppercase tracking-[0.2em] font-bold shrink-0 z-30">
          <div className="flex flex-wrap items-center gap-2 sm:gap-6 text-center sm:text-left">
            <span className="text-slate-500">Live Audit Trail:</span>
            {activityLogs.length > 0 ? (
              <span className="text-slate-300">
                {activityLogs[0].userName} - {activityLogs[0].details.toLowerCase()}{' '}
                <span className="text-slate-500 font-mono ml-1">({new Date(activityLogs[0].createdAt).toLocaleTimeString()})</span>
              </span>
            ) : (
              <span className="text-slate-300">No recent ledger transactions</span>
            )}
            <span className="hidden sm:inline text-slate-700">|</span>
            <span className="text-emerald-400 hidden sm:inline">Plaid Node Verified</span>
          </div>
          <div className="flex items-center gap-4 mt-1 sm:mt-0">
            <span className="text-blue-400 font-mono">Ledger integrity: 100% SHA-256 Valid</span>
            <svg className="w-4 h-4 text-emerald-500 fill-current hidden sm:block" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"/>
            </svg>
          </div>
        </footer>
      )}

    </div>
  );
}
