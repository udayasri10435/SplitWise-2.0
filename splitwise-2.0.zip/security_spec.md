# Security Specification: SplitWise 2.0 Firestore Rules

## 1. Data Invariants
1. **Authenticated Users Only**: No anonymous reads or writes of ledger groups. A user must be signed in with a verified email to read or write standard group expenses.
2. **Group Member Access Control (ABAC)**: A user can only view or write to a group and its nested expenses/activity logs if they are listed in the group's `members` array.
3. **Immutability of Key Fields**: Once an expense or group is created, its `id`, `groupId`, and critical structural fields cannot be spoofed or rewritten by other users.
4. **Valid Schema Structure**: Updates must preserve required field structures and only modify allowed keys (e.g., status, soft-delete timestamp) depending on user roles.

---

## 2. The "Dirty Dozen" Spoofing & Poisoning Payloads

Below are twelve malicious payloads that represent attacks on SplitWise 2.0's ledger system. Our security rules will block all of these payloads with `PERMISSION_DENIED`.

### Payload 1: Group Creation Identity Spoofing (Attacker sets creator to someone else)
```json
{
  "id": "group123",
  "name": "Hacked Group",
  "members": ["attacker@example.com"],
  "createdAt": "2026-06-29T12:00:00Z",
  "createdBy": "victim_user_uid", // Attempt to spoof creator
  "currency": "USD"
}
```

### Payload 2: Member Expansion (Attacker adds themselves to a private group they do not belong to)
*Attempting to write to `/groups/private_group_id` by adding `attacker@example.com` to the `members` field when the attacker is not already a member.*
```json
{
  "id": "private_group_id",
  "name": "Private Group",
  "members": ["victim@example.com", "attacker@example.com"],
  "createdAt": "2026-06-29T12:00:00Z",
  "createdBy": "victim@example.com",
  "currency": "USD"
}
```

### Payload 3: Blanket Expense Read (Attacker attempts to query all expenses across all groups)
*Attempting to call `list` or `get` on `/groups/some_private_group/expenses/expense_1` when not in the group members.*

### Payload 4: Expense Creation Spoofing (Attacker sets `paidBy` to another user's email)
```json
{
  "id": "expense99",
  "groupId": "group123",
  "title": "Expensive Dinner",
  "paidBy": "victim@example.com", // Spoofed payer
  "totalAmount": 1000,
  "createdAt": "2026-06-29T12:00:00Z"
}
```

### Payload 5: Deny-of-Wallet Long ID Injection
*Attempting to create an expense document with a 2MB long ID to bloat the Firestore index storage.*
`match /groups/{groupId}/expenses/{expenseId}` where `expenseId` is a 10,000 character string.

### Payload 6: Value Poisoning - Malicious Amount Type Update
```json
{
  "totalAmount": "one_million_dollars" // Type hijacking (string instead of number)
}
```

### Payload 7: Timestamp Hijacking (Attacker attempts to forge `createdAt` back to 2010)
```json
{
  "createdAt": "2010-01-01T00:00:00Z" // Forged creation date bypassing request.time
}
```

### Payload 8: Soft-Delete Hijacking (Attacker soft-deletes a victim's expense they didn't create)
*A non-member or non-creator trying to update `deletedAt` on `/groups/group_id/expenses/victim_expense`.*

### Payload 9: Shadow Field Injection (Attacker appends secret backdoor attributes to user profile)
```json
{
  "name": "John Doe",
  "isSystemAdmin": true // Injecting unauthorized admin status
}
```

### Payload 10: Empty Group Name bypass
```json
{
  "id": "group123",
  "name": "", // Empty name should be rejected by string size checks
  "members": ["attacker@example.com"],
  "createdAt": "2026-06-29T12:00:00Z",
  "createdBy": "attacker_uid",
  "currency": "USD"
}
```

### Payload 11: Currency Hijacking (Setting currency to an unsupported 50-character string)
```json
{
  "currency": "VERY_LONG_INVALID_CURRENCY_CODE_THAT_BLUMPS_THE_UI_LAYOUT_GRID"
}
```

### Payload 12: Orphaned Expense Writing (Creating an expense in a group that does not exist)
*Attempting to write to `/groups/non_existent_group/expenses/exp1`.*

---

## 3. Firestore Rules Validation Strategy
These security vulnerabilities will be blocked by the structural integrity rules defined inside `firestore.rules`.
Every read operation will verify that the requesting user's email or UID is in the `get(/databases/$(database)/documents/groups/$(groupId)).data.members` list.
Every write operation will verify schemas using strict helper functions: `isValidGroup()`, `isValidExpense()`, and `isValidActivityLog()`.
Timestamp fields will be locked to `request.time`.
Immutability of parent resource links is verified via `incoming().groupId == existing().groupId` checks.
