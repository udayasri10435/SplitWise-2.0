import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

// Increase JSON body parser limits to handle raw images
app.use(express.json({ limit: '15mb' }));

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// API Routes
app.post('/api/scan-receipt', async (req, res) => {
  try {
    const { imageBase64, isPro } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'No image provided' });
    }

    if (!ai) {
      // If no API key, return high-quality fallback mocked parsed receipt so user can demo
      console.warn('GEMINI_API_KEY is not configured. Returning premium demo mock parsing data.');
      return res.json({
        merchant: "Premium Bistro & Bar",
        date: new Date().toISOString().split('T')[0],
        items: [
          { name: "Artisanal Burger", price: 18.00, quantity: 1, total: 18.00 },
          { name: "Artisanal Burger", price: 18.00, quantity: 1, total: 18.00 },
          { name: "Truffle Fries", price: 12.00, quantity: 1, total: 12.00 },
          { name: "Craft IPA Beer", price: 9.00, quantity: 1, total: 9.00 },
          { name: "Craft IPA Beer", price: 9.00, quantity: 1, total: 9.00 },
          { name: "Red Wine Glass", price: 14.00, quantity: 1, total: 14.00 }
        ],
        subtotal: 80.00,
        tax: 6.40,
        totalAmount: 86.40,
        confidence: 94
      });
    }

    // Pro tier uses a higher intelligence model; Free tier uses general model
    // gemini-2.5-pro for smart semantic layout analysis, gemini-2.5-flash for rapid parsing
    const model = isPro ? 'gemini-2.5-pro' : 'gemini-2.5-flash';

    // Strip image metadata header
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, '');

    const systemInstruction = `You are an expert receipt parser. Analyze the receipt image and extract:
1. Merchant/Store Name (under "merchant").
2. Transaction Date (under "date") in YYYY-MM-DD format if available.
3. Line items with: "name", "price", "quantity", and "total".
4. CRITICAL RULE - MULTI-QUANTITY SPLITTING (THE "GROUPING" HACK):
   If any line item indicates multiple quantities (e.g. "Burger x 2" for $24.00, or "2 Draft Beer" for $18.00, or "Pizza (Qty: 3)" for $45.00), you MUST automatically expand and split them into separate, individual single-quantity line items (e.g. create two distinct "Burger" entries at $12.00 each; or three separate "Pizza" entries at $15.00 each). This allows different users to be assigned to separate units of the same item.
5. "subtotal", "tax", and "totalAmount".
6. "confidence" score between 0 and 100 representing your clarity of reading the receipt. If there are ambiguous or blurry items, lower the score.

Provide the response strictly in JSON format matching the schema requested.`;

    const responseSchema = {
      type: "OBJECT",
      properties: {
        merchant: { type: "STRING" },
        date: { type: "STRING" },
        items: {
          type: "ARRAY",
          items: {
            type: "OBJECT",
            properties: {
              name: { type: "STRING" },
              price: { type: "NUMBER" },
              quantity: { type: "INTEGER" },
              total: { type: "NUMBER" }
            },
            required: ["name", "price", "quantity", "total"]
          }
        },
        subtotal: { type: "NUMBER" },
        tax: { type: "NUMBER" },
        totalAmount: { type: "NUMBER" },
        confidence: { type: "INTEGER" }
      },
      required: ["merchant", "items", "subtotal", "tax", "totalAmount", "confidence"]
    };

    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          role: 'user',
          parts: [
            { text: "Extract structured receipt details from this image. Split multi-quantity lines as specified." },
            {
              inlineData: {
                mimeType: 'image/jpeg',
                data: base64Data
              }
            }
          ]
        }
      ],
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error('No receipt parsing data returned by the model.');
    }

    const result = JSON.parse(text);
    return res.json(result);
  } catch (error: any) {
    console.error('Scan receipt API error:', error);
    return res.status(500).json({ error: error.message || 'Error processing receipt scan' });
  }
});

// Serve static exchange rates for the multi-currency conversions
app.get('/api/exchange-rates', (req, res) => {
  res.json({
    base: 'USD',
    rates: {
      USD: 1.0,
      EUR: 0.92,
      GBP: 0.79,
      JPY: 156.45,
      CAD: 1.37,
      AUD: 1.51,
      INR: 83.50,
      SGD: 1.35
    }
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SplitWise 2.0 full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
